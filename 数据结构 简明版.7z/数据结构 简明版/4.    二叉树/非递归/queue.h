#ifndef  __QUEUE_H
#define  __QUEUE_H


#define  QUEUE_SIZE  100

struct queue {
    int write;
    int read;
    void* q[QUEUE_SIZE];
    int num;
};
typedef struct queue Queue_t;


void QueueInit(Queue_t* pq);

int QueueSend(Queue_t* pq, void* msg);

int QueueReceive(Queue_t* pq, void** pmsg);

int QueuePeek(Queue_t* pq, void** pmsg);

int QueueIsEmpty(Queue_t* pq);

int QueueIsFull(Queue_t* pq);


#endif
