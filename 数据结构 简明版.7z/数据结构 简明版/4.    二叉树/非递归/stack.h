#ifndef  __STACK_H
#define  __STACK_H

#define STACK_BUFFER_SIZE 50

struct stack {
	int top;
	void *s[STACK_BUFFER_SIZE];
};
typedef struct stack Stack_t;


void StackInit(Stack_t* ps);

int StackPush(Stack_t* ps, void* x);

int StackPop(Stack_t* ps, void** px);

int StackGetTop(Stack_t* ps, void** px);

int StackIsEmpty(Stack_t* ps);

int StackIsFull(Stack_t* ps);


#endif