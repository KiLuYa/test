#include "queue.h"

#ifndef NULL
#define NULL 0
#endif

void QueueInit(Queue_t* pq)
{
	pq->num = 0;
	pq->write = NULL;
	pq->read = NULL;
}

int QueueSend(Queue_t* pq, void* msg)
{
	int res;

	if (pq->num == QUEUE_SIZE)
		res = 0;
	else
	{
		pq->q[pq->write] = msg;
		pq->write++;
		if (pq->write == QUEUE_SIZE)
			pq->write = 0;
		pq->num++;
		res = 1;
	}

	return res;
}

int QueueReceive(Queue_t* pq, void** pmsg)
{
	int res;

	if (pq->num == 0)
		res = 0;
	else
	{
		*pmsg = pq->q[pq->read];
		pq->read++;
		if (pq->read == QUEUE_SIZE)
			pq->read = 0;
		pq->num--;
		res = 1;
	}

	return res;
}

int QueuePeek(Queue_t* pq, void** pmsg)
{
	int res;

	if (pq->num == 0)
		res = 0;
	else
	{
		*pmsg = pq->q[pq->read];
		res = 1;
	}

	return res;
}

int QueueIsEmpty(Queue_t* pq)
{
	int res;

	if (pq->num == 0)
		res = 1;
	else
		res = 0;

	return res;
}

int QueueIsFull(Queue_t* pq)
{
	int res;

	if (pq->num == QUEUE_SIZE)
		res = 1;
	else
		res = 0;

	return res;
}
