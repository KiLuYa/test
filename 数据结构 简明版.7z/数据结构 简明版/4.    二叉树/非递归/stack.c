#include "stack.h"


void StackInit(Stack_t* ps)
{
	ps->top = 0;
}

int StackPush(Stack_t* ps, void* x)
{
	int res;

	if (ps->top == STACK_BUFFER_SIZE)
		res = 0;
	else
	{
		ps->s[ps->top] = x;
		ps->top++;
		res = 1;
	}

	return res;
}

int StackPop(Stack_t* ps, void** px)
{
	int res;

	if (ps->top == 0)
		res = 0;
	else
	{
		ps->top--;
		*px = ps->s[ps->top];
		res = 1;
	}

	return res;
}

int StackGetTop(Stack_t* ps, void** px)
{
	int res;
	int idx;

	if (ps->top == 0)
		res = 0;
	else
	{
		idx = ps->top - 1;
		*px = ps->s[idx];
		res = 1;
	}

	return res;
}

int StackIsEmpty(Stack_t* ps)
{
	int res;

	if (ps->top == 0)
		res = 1;
	else
		res = 0;

	return res;
}

int StackIsFull(Stack_t* ps)
{
	int res;

	if (ps->top == STACK_BUFFER_SIZE)
		res = 1;
	else
		res = 0;

	return res;
}
