#include "bitree.h"
#include "stack.h"
#include "queue.h"
#include <stdlib.h>  //����mallco��free����
#include <stdio.h>


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *bitree_malloc(int size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= UBaseType_t

	return p;
}

static void bitree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



Bitree_t BitreeCreate(char *pStr)
{
	Bitree_t p;
	Stack_t s;
	Bitree_t cbt;
	Bitree_t *pt;

	StackInit(&s);
	cbt = NULL;
	pt = &cbt;

	while (*pStr != '\0')
	{
		if (*pStr == '.')
		{
			*pt = NULL;
			if (StackPop(&s, (void **)&p))
				pt = &(p->right);
			else
				break;
		}
		else
		{
			p = (Bitree_t)bitree_malloc(sizeof(BitreeNode_t));
			p->left = NULL;
			p->right = NULL;
			p->p = (void *)*pStr;
			*pt = p;
			pt = &(p->left);
			StackPush(&s, (void *)p);
		}

		pStr++;
	}

	return cbt;
}

void BitreeDelete(Bitree_t bt)
{
	Bitree_t p;
	Stack_t s;
	Bitree_t last;

	p = bt;
	StackInit(&s);
	last = NULL;

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackGetTop(&s, (void **)&p);
			if (p->right == NULL || p->right == last)
			{
				StackPop(&s, (void **)&p);
				bitree_free(p);
				last = p;
				p = NULL;
			}
			else
				p = p->right;
		}
	}
}

Bitree_t BitreeCopy(Bitree_t sbt)
{
	Bitree_t p;
	Stack_t s;
	Bitree_t dbt;
	Bitree_t pn, *ppn;
	Stack_t s2;

	p = sbt;
	StackInit(&s);
	dbt = NULL;
	ppn = &dbt;
	StackInit(&s2);

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			pn = (Bitree_t)bitree_malloc(sizeof(BitreeNode_t));
			pn->p = p->p;
			*ppn = pn;
			ppn = &(pn->left);
			StackPush(&s2, (void *)pn);

			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			*ppn = NULL;

			StackPop(&s, (void **)&p);
			p = p->right;
			StackPop(&s2, (void **)&pn);
			ppn = &(pn->right);
		}
	}
	*ppn = NULL;

	return dbt;
}



void BitreePreOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{
	Bitree_t p;
	Stack_t s;

	p = bt;
	StackInit(&s);

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			visitFunc(p);
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackPop(&s, (void **)&p);
			p = p->right;
		}
	}
}

void BitreeInOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{
	Bitree_t p;
	Stack_t s;

	p = bt;
	StackInit(&s);

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackPop(&s, (void **)&p);
			visitFunc(p);
			p = p->right;
		}
	}
}

void BitreePostOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{
	Bitree_t p;
	Stack_t s;
	Bitree_t last;

	p = bt;
	StackInit(&s);
	last = NULL;

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackGetTop(&s, (void **)&p);
			if (p->right == NULL || p->right == last)
			{
				StackPop(&s, (void **)&p);
				visitFunc(p);
				last = p;
				p = NULL;
			}
			else
				p = p->right;
		}
	}
}

void BitreeLayerOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{
	Bitree_t p;
	Queue_t q;

	if (bt == NULL)
		return;

	QueueInit(&q);
	QueueSend(&q, (void *)bt);

	while (!QueueIsEmpty(&q))
	{
		QueueReceive(&q, (void **)&p);
		visitFunc(p);
		if (p->left)
			QueueSend(&q, (void *)(p->left));
		if (p->right)
			QueueSend(&q, (void *)(p->right));
	}
}


int BitreeGetNodesNum(Bitree_t bt)
{
	int num = 0;
	Bitree_t p;
	Stack_t s;

	p = bt;
	StackInit(&s);

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			num++;
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackPop(&s, (void **)&p);
			p = p->right;
		}
	}

	return num;
}

int BitreeGetTerminalNodesNum(Bitree_t bt)
{
	int num = 0;
	Bitree_t p;
	Stack_t s;

	p = bt;
	StackInit(&s);

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			if(p->left==NULL && p->right==NULL)
				num++;
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackPop(&s, (void **)&p);
			p = p->right;
		}
	}

	return num;
}

int BitreeGetHeight(Bitree_t bt)
{
	int h = 0;
	Bitree_t p;
	Stack_t s;
	Bitree_t last;

	p = bt;
	StackInit(&s);
	last = NULL;

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackGetTop(&s, (void **)&p);
			if (p->right == NULL || p->right == last)
			{
				StackPop(&s, (void **)&p);
				
				if (s.top + 1 > h)
					h = s.top + 1;

				last = p;
				p = NULL;
			}
			else
				p = p->right;
		}
	}

	return h;
}

int BitreeGetWidth(Bitree_t bt)
{
	int w = 0, wmax = 0;
	int oldLayer = 1;
	int newLayer;
	Bitree_t p;
	Queue_t q;

	if (bt == NULL)
		return 0;

	QueueInit(&q);
	QueueSend(&q, (void *)bt);
	QueueSend(&q, (void *)oldLayer);

	while (!QueueIsEmpty(&q))
	{
		QueueReceive(&q, (void **)&p);
		QueueReceive(&q, (void **)&newLayer);
		if (newLayer == oldLayer)
			w++;
		else
		{
			if (w > wmax)
				wmax = w;
			w = 1;
			oldLayer = newLayer;
		}

		if (p->left)
		{
			QueueSend(&q, (void *)(p->left));
			QueueSend(&q, (void *)(newLayer + 1));
		}
		if (p->right)
		{
			QueueSend(&q, (void *)(p->right));
			QueueSend(&q, (void *)(newLayer + 1));
		}
	}
	if (w > wmax)
		wmax = w;

	return wmax;
}

void BitreeVisitPath(Bitree_t bt, BitreeNode_t *pNode, BitreeVisitFunc_t visitFunc)
{
	Bitree_t p;
	Stack_t s;
	Bitree_t last;

	p = bt;
	StackInit(&s);
	last = NULL;

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackGetTop(&s, (void **)&p);
			if (p->right == NULL || p->right == last)
			{
				StackPop(&s, (void **)&p);
				
				if (p == pNode)
				{
					for (int i = 0; i < s.top; i++)
						visitFunc((Bitree_t)s.s[i]);
					visitFunc(p);
					break;
				}

				last = p;
				p = NULL;
			}
			else
				p = p->right;
		}
	}
}

/**
 * by inverse-inorder traversal
 */
void BitreePrint(Bitree_t bt, int n, BitreeVisitFunc_t visitFunc)
{
	Bitree_t p;
	Stack_t s;

	p = bt;
	StackInit(&s);

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			StackPush(&s, (void *)p);
			p = p->right;
			StackPush(&s, (void *)n);
			n++;
		}
		else
		{
			StackPop(&s, (void **)&n);
			StackPop(&s, (void **)&p);
			for (int i = 0; i < n; i++)
				printf(" ");
			visitFunc(p);
			printf("\n");
			p = p->left;
			n++;
		}
	}
}


void BitreeSwitchChildren(Bitree_t bt)
{
	Bitree_t tmp;
	Bitree_t p;
	Stack_t s;
	Bitree_t last;

	p = bt;
	StackInit(&s);
	last = NULL;

	while (p != NULL || !StackIsEmpty(&s))
	{
		if (p != NULL)
		{
			StackPush(&s, (void *)p);
			p = p->left;
		}
		else
		{
			StackGetTop(&s, (void **)&p);
			if (p->right == NULL || p->right == last)
			{
				StackPop(&s, (void **)&p);
				
				tmp = p->left;
				p->left = p->right;
				p->right = tmp;

				last = p;
				p = NULL;
			}
			else
				p = p->right;
		}
	}
}


int BitreeIsSimilar(Bitree_t bt1, Bitree_t bt2)
{
	Bitree_t p1, p2;
	Stack_t s1, s2;
	int ret = 1;

	if (bt1 == NULL && bt2 == NULL)
		return 1;

	p1 = bt1;
	p2 = bt2;
	StackInit(&s1);
	StackInit(&s2);

	while (p1 != NULL || !StackIsEmpty(&s1))
	{
		if (p1 != NULL)
		{
			if (p2 == NULL)
			{
				ret = 0;
				break;
			}

			StackPush(&s1, (void *)p1);
			p1 = p1->left;
			StackPush(&s2, (void *)p2);
			p2 = p2->left;
		}
		else
		{
			if (p2 != NULL)
			{
				ret = 0;
				break;
			}

			StackPop(&s1, (void **)&p1);
			p1 = p1->right;
			StackPop(&s2, (void **)&p2);
			p2 = p2->right;
		}
	}
	if (p2 != NULL)
		ret = 0;

	return ret;
}

int BitreeIsSame(Bitree_t bt1, Bitree_t bt2)
{
	Bitree_t p1, p2;
	Stack_t s1, s2;
	int ret = 1;

	if (bt1 == NULL && bt2 == NULL)
		return 1;

	p1 = bt1;
	p2 = bt2;
	StackInit(&s1);
	StackInit(&s2);

	while (p1 != NULL || !StackIsEmpty(&s1))
	{
		if (p1 != NULL)
		{
			if (p2 == NULL)
			{
				ret = 0;
				break;
			}

			if (p1->p != p2->p)
			{
				ret = 0;
				break;
			}

			StackPush(&s1, (void *)p1);
			p1 = p1->left;
			StackPush(&s2, (void *)p2);
			p2 = p2->left;
		}
		else
		{
			if (p2 != NULL)
			{
				ret = 0;
				break;
			}

			StackPop(&s1, (void **)&p1);
			p1 = p1->right;
			StackPop(&s2, (void **)&p2);
			p2 = p2->right;
		}
	}
	if (p2 != NULL)
		ret = 0;

	return ret;
}
