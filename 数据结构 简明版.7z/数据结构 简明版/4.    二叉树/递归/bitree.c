#include "bitree.h"
#include <stdlib.h>  //����mallco��free����
#include <stdio.h>


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *bitree_malloc(int size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= UBaseType_t

	return p;
}

static void bitree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */




Bitree_t BitreeCreate(char **pStr)
{
	Bitree_t bt;
	char c;

	c = **pStr;

	if (c == '.')
	{
		*pStr = *pStr + 1;
		return NULL;
	}
	if (c == '\0')
		return NULL;
	
	bt = (Bitree_t)bitree_malloc(sizeof(BitreeNode_t));
	if (bt == NULL)
	{
		printf("fetal error: dead loop\n");
		while (1);
	}

	bt->p = (void *)c;
	*pStr = *pStr + 1;
	bt->left = BitreeCreate(pStr);
	bt->right = BitreeCreate(pStr);

	return bt;
}

void BitreeDelete(Bitree_t bt)
{
	if (bt != NULL)
	{
		BitreeDelete(bt->left);
		BitreeDelete(bt->right);
		bitree_free(bt);
	}
}

Bitree_t BitreeCopy(Bitree_t sbt)
{
	Bitree_t dbt = NULL;

	if (sbt != NULL)
	{
		dbt = (Bitree_t)bitree_malloc(sizeof(BitreeNode_t));
		dbt->p = sbt->p;
		dbt->left = BitreeCopy(sbt->left);
		dbt->right = BitreeCopy(sbt->right);
	}

	return dbt;
}



void BitreePreOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{
	if (bt != NULL)
	{
		visitFunc(bt);
		BitreePreOrder(bt->left, visitFunc);
		BitreePreOrder(bt->right, visitFunc);
	}
}

void BitreeInOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{
	if (bt != NULL)
	{
		BitreeInOrder(bt->left, visitFunc);
		visitFunc(bt);
		BitreeInOrder(bt->right, visitFunc);
	}
}

void BitreePostOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{
	if (bt != NULL)
	{
		BitreePostOrder(bt->left, visitFunc);
		BitreePostOrder(bt->right, visitFunc);
		visitFunc(bt);
	}
}

void BitreeLayerOrder(Bitree_t bt, BitreeVisitFunc_t visitFunc)
{

}


int BitreeGetNodesNum(Bitree_t bt)
{
	int num = 0;

	if (bt != NULL)
	{
		num = 1 + BitreeGetNodesNum(bt->left) + BitreeGetNodesNum(bt->right);
	}
	return num;
}

int BitreeGetTerminalNodesNum(Bitree_t bt)
{
	int num;

	if (bt == NULL)
		num = 0;
	else if (bt->left == NULL && bt->right == NULL)
		num = 1;
	else
		num = BitreeGetTerminalNodesNum(bt->left) + BitreeGetTerminalNodesNum(bt->right);

	return num;
}

int BitreeGetHeight(Bitree_t bt)
{
	int hl, hr, h;

	if (bt == NULL)
		h = 0;
	else
	{
		hl = BitreeGetHeight(bt->left);
		hr = BitreeGetHeight(bt->right);
		h = (hl > hr) ? hl : hr;
		h = h + 1;
	}

	return h;
}

int BitreeGetWidth(Bitree_t bt)
{
	return 0;
}

void BitreeVisitPath(Bitree_t bt, BitreeNode_t *pNode, BitreeVisitFunc_t visitFunc)
{

}

/**
 * by inverse-inorder traversal
 */
void BitreePrint(Bitree_t bt, int n, BitreeVisitFunc_t visitFunc)
{
	if (bt != NULL)
	{
		BitreePrint(bt->right, n + 1, visitFunc);
		for (int i = 0; i < n; i++)
			printf(" ");
		visitFunc(bt);
		printf("\n");
		BitreePrint(bt->left, n + 1, visitFunc);
	}
}


void BitreeSwitchChildren(Bitree_t bt)
{
	Bitree_t tmp;

	if (bt != NULL)
	{
		BitreeSwitchChildren(bt->left);
		BitreeSwitchChildren(bt->right);

		tmp = bt->left;
		bt->left = bt->right;
		bt->right = tmp;
	}
}


int BitreeIsSimilar(Bitree_t bt1, Bitree_t bt2)
{
	int ret;

	if (bt1 == NULL && bt2 == NULL)
		ret = 1;
	else if (bt1 == NULL || bt2 == NULL)
		ret = 0;
	else
	{
		ret = BitreeIsSimilar(bt1->left, bt2->left) && BitreeIsSimilar(bt1->right, bt2->right);
		/**
		 * ע�⣺���д���Ǻ��н����ģ�&&������ڵ�һ��������Ϊ0�������ֱ�ӷ���0�������ü���ڶ���������
		 * ����һ���Ż���д�������ԶԱ��������룺
		 * like1 = BitreeIsSimilar(bt1->left, bt2->left);
		 * like2 = BitreeIsSimilar(bt1->right, bt2->right)
		 * ret = like1 && like2
		 */
	}

	return ret;
}

int BitreeIsSame(Bitree_t bt1, Bitree_t bt2)
{
	int ret;

	if (bt1 == NULL && bt2 == NULL)
		ret = 1;
	else if (bt1 == NULL || bt2 == NULL)
		ret = 0;
	else
	{
		if (bt1->p != bt2->p)
			ret = 0;
		else
			ret = BitreeIsSame(bt1->left, bt2->left) && BitreeIsSame(bt1->right, bt2->right);
		/**
		 * ע�⣺���д���Ǻ��н����ģ�&&������ڵ�һ��������Ϊ0�������ֱ�ӷ���0�������ü���ڶ���������
		 * ����һ���Ż���д�������ԶԱ��������룺
		 * same1 = BitreeIsSame(bt1->left, bt2->left);
		 * same2 = BitreeIsSame(bt1->right, bt2->right)
		 * ret = same1 && same2
		 */
	}

	return ret;
}
