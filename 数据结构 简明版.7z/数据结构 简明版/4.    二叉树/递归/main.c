#include "bitree.h"
#include <stdio.h>


void visit(Bitree_t bt)
{
	printf("%c", (char)bt->p);
}


int main()
{
	// ����: BitreeCreate, BitreeCopy, BitreeDelete
	// ����: BitreePrint
	/*
	char str1[64] = "abd...c..";
	char str2[64] = "ab.d..c..";
	char str3[64] = "a...";
	char str4[64] = "a.";
	char *pStr;
	Bitree_t bt, dbt;

	pStr = str1;
	bt = BitreeCreate(&pStr);
	BitreePrint(bt, 0, visit);
	printf("\n");

	pStr = str2;
	bt = BitreeCreate(&pStr);
	BitreePrint(bt, 0, visit);
	printf("\n");

	pStr = str3;
	bt = BitreeCreate(&pStr);
	BitreePrint(bt, 0, visit);
	printf("\n");

	pStr = str4;
	bt = BitreeCreate(&pStr);
	BitreePrint(bt, 0, visit);
	printf("\n");

	pStr = str2;
	bt = BitreeCreate(&pStr);
	//BitreePrint(bt, 0, visit);

	dbt = BitreeCopy(bt);
	BitreePrint(dbt, 0, visit);
	printf("\n");

	BitreeDelete(bt);
	BitreeDelete(dbt);
	*/

	//����: BitreePreOrder, BitreeInOrder, BitreePostOrder, //BitreeLayerOrder
	//����: BitreeGetNodesNum, BitreeGetTerminalNodesNum, BitreeGetHeight, //BitreeGetWidth
	//����: BitreeVisitPath, BitreeSwitchChildren
	/*
	char str1[64] = "abd...c..";
	char *pStr;
	Bitree_t bt;

	pStr = str1;
	bt = BitreeCreate(&pStr);
	BitreePrint(bt, 0, visit);
	printf("\n");
	printf("pre order:\n");
	BitreePreOrder(bt, visit);
	printf("\n");
	printf("in order:\n");
	BitreeInOrder(bt, visit);
	printf("\n");
	printf("post order:\n");
	BitreePostOrder(bt, visit);
	printf("\n");

	printf("nodes number:  %d\n", BitreeGetNodesNum(bt));
	printf("terminal nodes number: %d\n", BitreeGetTerminalNodesNum(bt));
	printf("height: %d\n", BitreeGetHeight(bt));
	
	BitreeSwitchChildren(bt);
	BitreePrint(bt, 0, visit);
	*/


	//����: BitreeIsSimilar, BitreeIsSame
	char str1[64] = "abd...c..";
	char str2[64] = "abc...d..";
	char str3[64] = "ab.d..c..";
	char *pStr;
	Bitree_t bt1, bt2, bt3, bt4;

	pStr = str1;
	bt1 = BitreeCreate(&pStr);
	pStr = str2;
	bt2 = BitreeCreate(&pStr);
	pStr = str3;
	bt3 = BitreeCreate(&pStr);
	bt4 = BitreeCopy(bt1);

	printf("similar compare bt1 & bt2:  %d\n", BitreeIsSimilar(bt1, bt2));
	printf("similar compare bt1 & bt3:  %d\n", BitreeIsSimilar(bt1, bt3));
	printf("same compare bt1 & bt2:  %d\n", BitreeIsSame(bt1, bt2));
	printf("same compare bt1 & bt4:  %d\n", BitreeIsSame(bt1, bt4));
	
}