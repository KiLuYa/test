
#include <stdio.h>
#include "stack.h"

int main()
{
	Stack_t s;
	int data;

	StackInit(&s);
	
	StackPush(&s, (void*)1);
	StackPush(&s, (void*)2);
	StackPush(&s, (void*)3);
	StackPush(&s, (void*)4);
	StackPush(&s, (void*)5);

	StackGetTop(&s, (void**)&data);
	printf("stack top: %d\r\n", data);

	StackPop(&s, (void**)&data);
	printf("stack out: %d\r\n", data);
	StackPop(&s, (void**)&data);
	printf("stack out: %d\r\n", data);
	StackPop(&s, (void**)&data);
	printf("stack out: %d\r\n", data);
	StackPop(&s, (void**)&data);
	printf("stack out: %d\r\n", data);
	StackPop(&s, (void**)&data);
	printf("stack out: %d\r\n", data);
}