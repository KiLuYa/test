
#include <stdio.h>
#include "queue.h"

int main()
{
	Queue_t q;
	int data;

	QueueInit(&q);

	QueueSend(&q, (void*)1);
	QueueSend(&q, (void*)2);
	QueueSend(&q, (void*)3);
	QueueSend(&q, (void*)4);
	QueueSend(&q, (void*)5);

	QueuePeek(&q, (void**)&data);
	printf("queue top: %d\r\n", data);

	QueueReceive(&q, (void**)&data);
	printf("queue out: %d\r\n", data);
	QueueReceive(&q, (void**)&data);
	printf("queue out: %d\r\n", data);
	QueueReceive(&q, (void**)&data);
	printf("queue out: %d\r\n", data);
	QueueReceive(&q, (void**)&data);
	printf("queue out: %d\r\n", data);
	QueueReceive(&q, (void**)&data);
	printf("queue out: %d\r\n", data);
}
