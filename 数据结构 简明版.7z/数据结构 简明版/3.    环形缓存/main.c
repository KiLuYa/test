
#include <stdio.h>
#include "ringbuf.h"

int main()
{
	Ringbuf_t r;
	char data[1024];
	int res;
	char recv[1024];

	for (int i = 0; i < 1024; i++)
		data[i] = 'a';

	RingbufInit(&r);

	printf("send 1024 bytes to buf.\r\n");
	res = RingbufWrite(&r, data, 1024);
	if (res == 0)
		printf("right. data is too large.\r\n");
	else
		printf("error.\r\n");

	printf("recv 1024 bytes.\r\n");
	res = RingbufRead(&r, recv, 1024);
	if (res == 0)
		printf("right. no data in buf.\r\n");
	else
		printf("error.\r\n");

	printf("send 256 bytes to buf.\r\n");
	res = RingbufWrite(&r, data, 256);
	if (res != 256)
		printf("error.\r\n");
	else
		printf("right.\r\n");
	printf("send 256 bytes to buf.\r\n");
	res = RingbufWrite(&r, data, 256);
	if (res != 256)
		printf("error.\r\n");
	else
		printf("right.\r\n");
	printf("send 1 byte to buf.\r\n");
	res = RingbufWrite(&r, data, 1);
	if (res != 0)
		printf("error.\r\n");
	else
		printf("right. buf is full\r\n");

	//printf("** %d **\r\n", r.num);
	printf("read 1024 bytes from buf.\r\n");
	res = RingbufRead(&r, recv, 1024);
	printf("res: %d\r\n", res);
	if (res == 512)
		printf("right.\r\n");
	else
		printf("error.\r\n");
}
