#include "ringbuf.h"


void RingbufInit(Ringbuf_t* pr)
{
	pr->write = 0;
	pr->read = 0;
	pr->num = 0;
}

int RingbufWrite(Ringbuf_t* pr, unsigned char* data, int len)
{
	int tot_wlen;
	int wlen;

	if (RINGBUF_SIZE - pr->num < len)
		tot_wlen = 0;
	else
	{
		tot_wlen = len;
		if (pr->read <= pr->write)
		{
			wlen = RINGBUF_SIZE - pr->write;
			if (wlen >= len)
			{
				wlen = len;
				memcpy(&(pr->buf[pr->write]), data, wlen);
				pr->write += wlen;
				if (pr->write == RINGBUF_SIZE)
					pr->write = 0;
				pr->num += wlen;
			}
			else
			{
				memcpy(&(pr->buf[pr->write]), data, wlen);
				//pr->write += wlen;
				pr->write = 0;
				pr->num += wlen;
				wlen = len - wlen;
				memcpy(&(pr->buf[0]), data+len-wlen, wlen);
				pr->write += wlen;
				pr->num += wlen;
			}
		}
		else
		{
			wlen = len;
			memcpy(&(pr->buf[pr->write]), data, wlen);
			pr->write += wlen;
			pr->num += wlen;
		}
	}

	return tot_wlen;
}

int RingbufRead(Ringbuf_t* pr, unsigned char* data, int len)
{
	int rlen;
	int tot_rlen = 0;

	if (pr->num == 0)
		return 0;

	if (pr->read >= pr->write)
	{
		rlen = RINGBUF_SIZE - pr->read;
		if (rlen >= len)
		{
			rlen = len;
			memcpy(data, &(pr->buf[pr->read]), rlen);
			pr->read += rlen;
			if (pr->read == RINGBUF_SIZE)
				pr->read = 0;
			pr->num -= rlen;
			tot_rlen = rlen;
		}
		else
		{
			int tmpLen;

			memcpy(data, &(pr->buf[pr->read]), rlen);
			pr->read = 0;
			pr->num -= rlen;
			tot_rlen = rlen;
			tmpLen = rlen;
			rlen = pr->write;
			if (rlen > len)
				rlen = len;
			memcpy(data+tmpLen, &(pr->buf[0]), rlen);
			pr->read += rlen;
			pr->num -= rlen;
			tot_rlen += rlen;
		}
	}
	else
	{
		rlen = pr->write - pr->read;
		if (rlen > len)
			rlen = len;
		memcpy(data, &(pr->buf[pr->read]), rlen);
		pr->read += rlen;
		pr->num -= rlen;
		tot_rlen = rlen;
	}

	return tot_rlen;
}

int RingbufIsEmpty(Ringbuf_t* pr)
{
	int ret;

	if (pr->num == 0)
		ret = 1;
	else
		ret = 0;

	return ret;
}

int RingbufIsFull(Ringbuf_t* pr)
{
	int ret;

	if (pr->num == RINGBUF_SIZE)
		ret = 1;
	else
		ret = 0;

	return ret;
}

int RingbufGetBytesNum(Ringbuf_t* pr)
{
	return pr->num;
}

int RingbufGetSpacesNum(Ringbuf_t* pr)
{
	return RINGBUF_SIZE - pr->num;
}
