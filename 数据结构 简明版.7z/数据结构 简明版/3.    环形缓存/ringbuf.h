#ifndef __RINGBUF_H
#define __RINGBUF_H

#define  RINGBUF_SIZE  512

struct ringbuf {
    int write;
    int read;
    int num;
    int buf[RINGBUF_SIZE];
};
typedef struct ringbuf Ringbuf_t;


void RingbufInit(Ringbuf_t* pr);

int RingbufWrite(Ringbuf_t* pr, unsigned char* data, int len);

int RingbufRead(Ringbuf_t* pr, unsigned char* data, int len);

int RingbufIsEmpty(Ringbuf_t* pr);

int RingbufIsFull(Ringbuf_t* pr);

int RingbufGetBytesNum(Ringbuf_t* pr);

int RingbufGetSpacesNum(Ringbuf_t* pr);


#endif
