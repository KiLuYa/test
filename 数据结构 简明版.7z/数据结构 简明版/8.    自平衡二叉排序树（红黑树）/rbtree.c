#include "rbtree.h"
#include <stdlib.h>  //����mallco��free����
#include <stdio.h>


#ifndef NULL
#define NULL 0
#endif

#define  RED    0
#define  BLACK  1


/* �ӿ��� ��� */

static void *rbtree_malloc(int size)
{
	void *p = malloc(size);

	return p;
}

static void rbtree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

/**
 * Rotate tree left.
 * Helper function for avltree_fixup( ).
 * x and x->right cannot be NULL.
 */
static void rotate_left(RBTree_t *pt, RBTreeNode_t *x)
{
	RBTreeNode_t *y = x->right;

	x->right = y->left;
	if (y->left != NULL)
		y->left->parent = x;

	y->left = x;

	if (x->parent == NULL)
		*pt = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;

	y->parent = x->parent;

	x->parent = y;
}

/**
 * Rotate tree right.
 * Helper function for avltree_fixup( ).
 * x and x->left cannot be NULL.
 */
static void rotate_right(RBTree_t *pt, RBTreeNode_t *x)
{
	RBTreeNode_t *y = x->left;

	x->left = y->right;
	if (y->right != NULL)
		y->right->parent = x;

	y->right = x;

	if (x->parent == NULL)
		*pt = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;

	y->parent = x->parent;

	x->parent = y;
}

/**
 * Transplant t2 to t1 in AVLTree.
 * t1 cannot be NULL��t2 can be NULL.
 */
static void transplant(RBTree_t *pt, RBTreeNode_t *t1, RBTreeNode_t *t2)
{
	if (t1->parent == NULL)
	{
		*pt = t2;
		if (t2 != NULL)
			t2->parent = NULL;
	}
	else
	{
		if (t1->parent->left == t1)
			t1->parent->left = t2;
		else
			t1->parent->right = t2;
		if (t2 != NULL)
			t2->parent = t1->parent;
	}
}

static void change_color(RBTreeNode_t *t1, RBTreeNode_t *t2)
{
	int color;

	color = t1->color;
	t1->color = t2->color;
	t2->color = color;
}

/**
 * Fixup the rbtree to stay balance after insert a node.
 */
static void rbtree_fixup_after_insert(RBTree_t *pt, RBTreeNode_t *z)
{
	while (1)
	{
		if (z->parent == NULL)
		{
			z->color = BLACK;
			break;
		}
		else if (z->parent->color == BLACK)
		{
			break;
		}
		else  //z->parent��Ϊ�գ�������ɫΪ�죬˵��p->parent->parentһ����Ϊ�գ�������ɫΪ��
		{
			if (z->parent->parent->left == z->parent)
			{
				if (z->parent->parent->right != NULL && z->parent->parent->right->color == RED)
				{
					z->parent->color = BLACK;
					z->parent->parent->right->color = BLACK;
					z->parent->parent->color = RED;
					z = z->parent->parent;
				}
				else
				{
					if (z->parent->right == z)
					{
						z = z->parent;
						rotate_left(rbt, z);
					}
					change_color(z->parent, z->parent->parent);
					z = z->parent->parent;
					rotate_right(rbt, z);
					break;
				}
			}
			else
			{
				if (z->parent->parent->left != NULL && z->parent->parent->left->color == RED)
				{
					z->parent->color = BLACK;
					z->parent->parent->left->color = BLACK;
					z->parent->parent->color = RED;
					z = z->parent->parent;
				}
				else
				{
					if (z->parent->left == z)
					{
						z = z->parent;
						rotate_right(rbt, z);
					}
					change_color(z->parent, z->parent->parent);
					z = z->parent->parent;
					rotate_left(rbt, z);
					break;
				}
			}
		}
	}
}

/**
 * Fixup the rbtree to stay balance after remove a node.
 */
static void rbtree_fixup_after_remove(RBTree_t *pt, RBTreeNode_t *x)
{
	RBTreeNode_t *w;

	while (1)
	{
		if (x->parent == NULL)
		{
			x->color = BLACK;
			break;
		}

		if (x->color == RED)
		{
			x->color = BLACK;
			break;
		}

		if (x->parent->left == x)
		{
			w = x->parent->right;
			if (w->color == RED)
			{
				change_color(x->parent, w);
				rotate_left(rbt, x->parent);
			}
			else
			{
				if (w->left->color == BLACK && w->right->color == BLACK)
				{
					w->color = RED;
					x = x->parent;
				}
				else if (w->right->color == BLACK)
				{
					change_color(w, w->left);
					rotate_right(rbt, w);
				}
				else
				{
					w->right->color = BLACK;
					change_color(w, x->parent);
					rotate_left(rbt, x->parent);
					break;
				}
			}
		}
		else
		{
			w = x->parent->left;
			if (w->color == RED)
			{
				change_color(w, x->parent);
				rotate_right(rbt, x->parent);
			}
			else
			{
				if (w->left->color == BLACK && w->right->color == BLACK)
				{
					w->color = RED;
					x = x->parent;
				}
				else if (w->left->color == BLACK)
				{
					change_color(w, w->right);
					rotate_left(rbt, w);
				}
				else
				{
					w->left->color = BLACK;
					change_color(w, x->parent);
					rotate_right(rbt, x->parent);
					break;
				}
			}
		}
	}
}

static void rbtree_fixup_after_remove_sp(RBTree_t *pt, RBTreeNode_t *x)
{
	if (x->left != NULL)
	{
		if (x->left->color == RED)
		{
			change_color(x, x->left);
			rotate_right(rbt, x);
		}

		if (x->left->left == NULL && x->left->right == NULL)
		{
			x->left->color = RED;
			rbtree_fixup_after_remove(rbt, x);
		}
		else
		{
			if (x->left->left == NULL && x->left->right != NULL)
			{
				change_color(x->left->right, x->left);
				rotate_left(rbt, x->left);
			}
			x->left->left->color = BLACK;
			change_color(x, x->left);
			rotate_right(rbt, x);
		}
	}
	else
	{
		if (x->right->color == RED)
		{
			change_color(x, x->right);
			rotate_left(rbt, x);
		}

		if (x->right->right == NULL && x->right->left == NULL)
		{
			x->right->color = RED;
			rbtree_fixup_after_remove(rbt, x);
		}
		else
		{
			if (x->right->right == NULL && x->right->left != NULL)
			{
				change_color(x->right->left, x->right);
				rotate_right(rbt, x->right);
			}
			x->right->right->color = BLACK;
			change_color(x, x->right);
			rotate_left(rbt, x);
		}
	}
}

/* ��̬�� �յ� */



/* API�� ��� */

RBTree_t RBTreeCreate(void **pd, int len, RBTreeNodeCompareFunc_t compare)
{
	RBTree_t rbt = NULL;

	for (int i = 0; i < len; i++)
		RBTreeInsert(&rbt, pd[i], compare);

	return rbt;
}

void RBTreeDelete(RBTree_t rbt)
{
	if (rbt != NULL)
	{
		RBTreeDelete(rbt->left);
		RBTreeDelete(rbt->right);
		rbtree_free(rbt);
	}
}

void RBTreeCopy(RBTree_t rbt, RBTree_t *pt)
{
	RBTreeNode_t *pn = NULL;

	if (rbt != NULL)
	{
		pn = (RBTreeNode_t *)rbtree_malloc(sizeof(RBTreeNode_t));
		if (pn == NULL)
		{
			printf("fatal error\r\n");
			while (1);
		}
		pn->color = rbt->color;
		pn->data = rbt->data;
		*pt = pn;
		RBTreeCopy(rbt->left, &(pn->left));
		RBTreeCopy(rbt->right, &(pn->right));
	}
	else
		*pt = NULL;
}


void RBTreeInsert(RBTree_t *pt, void *data, RBTreeNodeCompareFunc_t compare)
{

}

int RBTreeRemove(RBTree_t *pt, void *data, RBTreeNodeCompareFunc_t compare)
{

}

void *RBTreeSearch(RBTree_t rbt, void *data, RBTreeNodeCompareFunc_t compare)
{
	void *d = NULL;

	while (rbt != NULL)
	{
		int res;

		res = compare(rbt->data, data);
		if (res == 0)
		{
			d = rbt->data;
			break;
		}
		else if (res == 1)
			rbt = rbt->left;
		else
			rbt = rbt->right;
	}

	return d;
}


void RBTreeInOrder(RBTree_t rbt, RBTreeNodeVisitFunc_t visit)
{
	if (rbt != NULL)
	{
		RBTreeInOrder(rbt->left, visit);
		visit(rbt->data);
		RBTreeInOrder(rbt->right, visit);
	}
}

void RBTreeReInOrder(RBTree_t rbt, RBTreeNodeVisitFunc_t visit)
{
	if (rbt != NULL)
	{
		RBTreeReInOrder(rbt->right, visit);
		visit(rbt->data);
		RBTreeReInOrder(rbt->left, visit);
	}
}

int RBTreeGetNodesNum(RBTree_t rbt)
{
	int num;

	if (rbt != NULL)
		num = RBTreeGetNodesNum(rbt->left) + RBTreeGetNodesNum(rbt->right) + 1;
	else
		num = 0;

	return num;
}

int RBTreeGetHeight(RBTree_t rbt)
{
	int hl, hr, h;

	if (rbt != NULL)
	{
		hl = RBTreeGetHeight(rbt->left);
		hr = RBTreeGetHeight(rbt->right);
		h = (hl > hr) ? hl : hr;
		h = h + 1;
	}
	else
		h = 0;

	return h;
}

int RBTreeGetWidth(RBTree_t rbt)
{
	return 0;
}


void RBTreePrint(RBTree_t rbt, RBTreeNodeVisitFunc_t visit, int n)
{
	if (rbt != NULL)
	{
		RBTreePrint(rbt->right, visit, n + 1);

		for (int i = 0; i < n; i++)
			printf(" ");
		visit(rbt->data);
		printf("\n");

		RBTreePrint(rbt->left, visit, n + 1);
	}
}

/* API�� �յ� */
