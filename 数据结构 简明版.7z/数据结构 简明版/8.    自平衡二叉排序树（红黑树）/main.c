
#include <stdio.h>
#include "rbtree.h"


void visit(void *data)
{
	printf("%d", (int)data);
}

int compare(void *dataNode, void *dataUser)
{
	int a = (int)dataNode;
	int b = (int)dataUser;

	if (a > b)
		return 1;
	else if (a == b)
		return 0;
	else
		return -1;
}


int main()
{
	int dat[10] = { 1, 2, 3, 4, 5, 6 };
	RBTree_t rbt;
	RBTree_t dt;
	int res;

	//���� RBTreeCreate, RBTreeDelete, RBTreeCopy, RBTreeInsert, RBTreeRemove, RBTreePrint
	rbt = RBTreeCreate((void **)dat, 6, compare);
	RBTreePrint(rbt, visit, 0);
	printf("\n\n");
	
	RBTreeInsert(&rbt, (void *)7, compare);
	RBTreePrint(rbt, visit, 0);
	printf("\n\n");

	RBTreeRemove(&rbt, (void *)1, compare);
	RBTreePrint(rbt, visit, 0);
	printf("\n\n");

	RBTreeRemove(&rbt, (void *)4, compare);
	RBTreePrint(rbt, visit, 0);
	printf("\n\n");

	RBTreeCopy(rbt, &dt);
	RBTreePrint(dt, visit, 2);
	printf("\n\n");

	RBTreeInsert(&dt, (void *)4, compare);
	RBTreePrint(dt, visit, 0);
	printf("\n\n");

	//���� RBTreeSearch, RBTreeInOrder, RBTreeReInOrder, RBTreeGetNodesNum, RBTreeGetHeight
	res = (int)RBTreeSearch(rbt, (void *)6, compare);
	printf("search result: %d\n", res);

	RBTreeInOrder(rbt, visit);
	printf("\n");

	RBTreeReInOrder(rbt, visit);
	printf("\n");

	printf("nodes number: %d\r\n", RBTreeGetNodesNum(rbt));
	printf("tree  height: %d\r\n", RBTreeGetHeight(rbt));
	
	RBTreeDelete(rbt);
	RBTreeDelete(dt);
}