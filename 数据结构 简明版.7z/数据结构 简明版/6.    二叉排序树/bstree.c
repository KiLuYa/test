#include "bstree.h"
#include <stdlib.h>  //����mallco��free����
#include <stdio.h>


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *bstree_malloc(int size)
{
	void *p = malloc(size);

	return p;
}

static void bstree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



BSTree_t BSTreeCreate(void **pd, int len, BSTreeNodeCompareFunc_t compare)
{
	BSTree_t bst = NULL;

	for (int i = 0; i < len; i++)
		BSTreeInsert(&bst, compare, pd[i]);

	return bst;
}

void BSTreeDelete(BSTree_t bst)
{
	if (bst != NULL)
	{
		BSTreeDelete(bst->left);
		BSTreeDelete(bst->right);
		bstree_free(bst);
	}
}

void BSTreeInsert(BSTree_t* pt, BSTreeNodeCompareFunc_t compare, void *data)
{
	BSTreeNode_t* pn;

	while (pt != NULL)
	{
		if (*pt != NULL)
		{
			pn = *pt;
			if (compare(pn->data, data) == 1)
				pt = &(pn->left);
			else
				pt = &(pn->right);
		}
		else
		{
			pn = (BSTreeNode_t *)bstree_malloc(sizeof(BSTreeNode_t));
			if(pn == NULL)
			{
				printf("fatal error\r\n");
				while (1);
			}
			pn->left = NULL;
			pn->right = NULL;
			pn->data = data;
			*pt = pn;
			pt = NULL;
		}
	}
}

int BSTreeRemove(BSTree_t* pt, BSTreeNodeCompareFunc_t compare, void* data)
{
	return 0;
}

void* BSTreeSearch(BSTree_t bst, BSTreeNodeCompareFunc_t compare, void* data)
{
	void *d = NULL;

	while (bst != NULL)
	{
		int res;

		res = compare(bst->data, data);
		if (res == 0)
		{
			d = bst->data;
			break;
		}
		else if (res == 1)
			bst = bst->left;
		else
			bst = bst->right;
	}
	
	return d;
}

void BSTreeInOrder(BSTree_t bst, BSTreeNodeVisitFunc_t visit)
{
	if (bst != NULL)
	{
		BSTreeInOrder(bst->left, visit);
		visit(bst->data);
		BSTreeInOrder(bst->right, visit);
	}
}

void BSTreeReInOrder(BSTree_t bst, BSTreeNodeVisitFunc_t visit)
{
	if (bst != NULL)
	{
		BSTreeReInOrder(bst->right, visit);
		visit(bst->data);
		BSTreeReInOrder(bst->left, visit);
	}
}

void BSTreePrint(BSTree_t bst, BSTreeNodeVisitFunc_t visit, int n)
{
	if (bst != NULL)
	{
		BSTreePrint(bst->right, visit, n + 1);

		for (int i = 0; i < n; i++)
			printf(" ");
		visit(bst->data);
		printf("\n");

		BSTreePrint(bst->left, visit, n + 1);
	}
}
