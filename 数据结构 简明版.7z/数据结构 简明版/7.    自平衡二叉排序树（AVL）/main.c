
#include <stdio.h>
#include "avltree.h"


void visit(void *data)
{
	printf("%d", (int)data);
}

int compare(void *dataNode, void *dataUser)
{
	int a = (int)dataNode;
	int b = (int)dataUser;

	if (a > b)
		return 1;
	else if (a == b)
		return 0;
	else
		return -1;
}


int main()
{
	int dat[10] = { 1, 2, 3, 4, 5, 6 };
	AVLTree_t avl;
	AVLTree_t dt;
	int res;

	//���� AVLTreeCreate, AVLTreeDelete, AVLTreeCopy, AVLTreeInsert, AVLTreeRemove, AVLTreePrint
	avl = AVLTreeCreate((void **)dat, 6, compare);
	AVLTreePrint(avl, visit, 0);
	printf("\n\n");
	
	AVLTreeInsert(&avl, (void *)7, compare);
	AVLTreePrint(avl, visit, 0);
	printf("\n\n");

	AVLTreeRemove(&avl, (void *)1, compare);
	AVLTreePrint(avl, visit, 0);
	printf("\n\n");

	AVLTreeRemove(&avl, (void *)4, compare);
	AVLTreePrint(avl, visit, 0);
	printf("\n\n");

	dt = AVLTreeCopy(avl);
	AVLTreePrint(dt, visit, 2);
	printf("\n\n");

	//���� AVLTreeSearch, AVLTreeInOrder, AVLTreeReInOrder, AVLTreeGetNodesNum, AVLTreeGetHeight
	res = (int)AVLTreeSearch(avl, (void *)6, compare);
	printf("search result: %d\n", res);

	AVLTreeInOrder(avl, visit);
	printf("\n");

	AVLTreeReInOrder(avl, visit);
	printf("\n");

	printf("nodes number: %d\r\n", AVLTreeGetNodesNum(avl));
	printf("tree  height: %d\r\n", AVLTreeGetHeight(avl));
	
	AVLTreeDelete(avl);
	AVLTreeDelete(dt);
}