#include "avltree.h"
//#include "stack.h"
//#include "queue.h"
#include <stdio.h>   //����printf����
#include <stdlib.h>  //����malloc��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *avltree_malloc(int size)
{
	void *p = malloc(size);

	return p;
}

static void avltree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

/**
 * Update pn->height. pn should not be NULL.
 */
static void update_height(AVLTreeNode_t *pn)
{
	int hl, hr;

	if (pn->left == NULL) hl = 0;
	else hl = pn->left->height;

	if (pn->right == NULL) hr = 0;
	else hr = pn->right->height;

	pn->height = (hl > hr ? hl : hr) + 1;
}

/**
 * return pn's height.
 */
static int get_height(AVLTreeNode_t *pn)
{
	int hig;

	if (pn != NULL)
		hig = pn->height;
	else
		hig = 0;

	return hig;
}

/**
 * Rotate tree left.
 * Helper function for avltree_fixup( ).
 * x and x->right cannot be NULL.
 */
static void rotate_left(AVLTree_t *pt, AVLTreeNode_t *x)
{
	AVLTreeNode_t *y = x->right;

	x->right = y->left;
	if (y->left != NULL)
		y->left->parent = x;

	y->left = x;

	if (x->parent == NULL)
		*pt = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;

	y->parent = x->parent;
	
	x->parent = y;

	update_height(x);  //the sequence cannot change
	update_height(y);
}

/**
 * Rotate tree right.
 * Helper function for avltree_fixup( ).
 * x and x->left cannot be NULL.
 */
static void rotate_right(AVLTree_t *pt, AVLTreeNode_t *x)
{
	AVLTreeNode_t *y = x->left;

	x->left = y->right;
	if (y->right != NULL)
		y->right->parent = x;

	y->right = x;

	if (x->parent == NULL)
		*pt = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;

	y->parent = x->parent;
	
	x->parent = y;

	update_height(x);  //the sequence cannot change
	update_height(y);
}

/**
 * Transplant t2 to t1 in AVLTree.
 * t1 cannot be NULL��t2 can be NULL.
 */
static void transplant(AVLTree_t *pt, AVLTreeNode_t *t1, AVLTreeNode_t *t2)
{
	if (t1->parent == NULL)
	{
		*pt = t2;
		if (t2 != NULL)
			t2->parent = NULL;
	}
	else
	{
		if (t1->parent->left == t1)
			t1->parent->left = t2;
		else
			t1->parent->right = t2;
		if (t2 != NULL)
			t2->parent = t1->parent;
	}
}

/**
 * Fixup the avltree to stay balance after insert a node.
 */
static void avltree_fixup_after_insert(AVLTree_t* pt, AVLTreeNode_t *z)
{
	int bf;  //balance factor

	while (z != NULL)
	{
		update_height(z);
		bf = get_height(z->left) - get_height(z->right);

		if (bf == 0)
			break;
		else if (bf == 2)
		{
			if (get_height(z->left->left) < get_height(z->left->right))
			{
				rotate_left(pt, z->left);
				//update_height(z->left->left);
			}
			rotate_right(pt, z);
			//update_height(z);
			break;
		}
		else if (bf == -2)
		{
			if (get_height(z->right->left) > get_height(z->right->right))
			{
				rotate_right(pt, z->right);
				//update_height(z->right->right);
			}
			rotate_left(pt, z);
			//update_height(z);
			break;
		}

		z = z->parent;
	}
}

/**
 * Fixup the avltree to stay balance after remove a node.
 */
static void avltree_fixup_after_remove(AVLTree_t *pt, AVLTreeNode_t *z)
{
	int bf;  //balance factor

	while (z != NULL)
	{
		update_height(z);
		bf = get_height(z->left) - get_height(z->right);

		if (bf == 1 || bf == -1)
			break;
		else if (bf == 2)
		{
			if (get_height(z->left->left) < get_height(z->left->right))
			{
				rotate_left(pt, z->left);
				//update_height(z->left->left);
			}
			rotate_right(pt, z);
			//update_height(z);
		}
		else if (bf == -2)
		{
			if (get_height(z->right->left) > get_height(z->right->right))
			{
				rotate_right(pt, z->right);
				//update_height(z->right->right);
			}
			rotate_left(pt, z);
			//update_height(z);
		}

		z = z->parent;
	}
}

/* ��̬�� �յ� */



/* API�� ��� */

AVLTree_t AVLTreeCreate(void **pd, int len, AVLTreeNodeCompareFunc_t compare)
{
	AVLTree_t avl = NULL;

	for (int i = 0; i < len; i++)
		AVLTreeInsert(&avl, pd[i], compare);

	return avl;
}

void AVLTreeDelete(AVLTree_t avl)
{
	if (avl != NULL)
	{
		AVLTreeDelete(avl->left);
		AVLTreeDelete(avl->right);
		avltree_free(avl);
	}
}

AVLTree_t AVLTreeCopy(AVLTree_t avl)
{
	AVLTreeNode_t *pn = NULL;

	if (avl != NULL)
	{
		pn = (AVLTreeNode_t *)avltree_malloc(sizeof(AVLTreeNode_t));
		if (pn == NULL)
		{
			printf("fatal error\r\n");
			while (1);
		}
		pn->height = avl->height;
		pn->data = avl->data;
		pn->left = AVLTreeCopy(avl->left);
		pn->right = AVLTreeCopy(avl->right);
	}
	
	return pn;
}


void AVLTreeInsert(AVLTree_t* pt, void *data, AVLTreeNodeCompareFunc_t compare)
{
	AVLTreeNode_t *pn, *prev, **ppn;
	
	if (pt == NULL)
		return;

	ppn = pt;
	prev = NULL;
	pn = *ppn;

	while (pn != NULL)
	{
		if (compare(pn->data, data) == 1)
		{
			ppn = &(pn->left);
			prev = pn;
			pn = pn->left;
		}
		else
		{
			ppn = &(pn->right);
			prev = pn;
			pn = pn->right;
		}
	}

	pn = (AVLTreeNode_t *)avltree_malloc(sizeof(AVLTreeNode_t));
	if (pn == NULL)
	{
		printf("fatal error\r\n");
		while (1);
	}
	pn->parent = NULL;
	pn->left = NULL;
	pn->right = NULL;
	pn->height = 1;
	pn->data = data;
	
	*ppn = pn;
	pn->parent = prev;
	
	avltree_fixup_after_insert(pt, pn->parent);
}

int AVLTreeRemove(AVLTree_t* pt, void *data, AVLTreeNodeCompareFunc_t compare)
{
	AVLTreeNode_t *pn, *r, *s;
	int res, ret;

	if (pt == NULL)
		return 0;

	pn = *pt;
	r = NULL;
	ret = 0;

	while (pn != NULL)
	{
		res = compare(pn->data, data);
		if (res == 0)
		{
			if (pn->left == NULL)
			{
				r = pn->parent;
				transplant(pt, pn, pn->right);
				avltree_free(pn);
			}
			else
			{
				s = pn->left;
				while (s->right != NULL)
					s = s->right;
				r = s->parent;
				transplant(pt, s, s->left);
				pn->data = s->data;
				avltree_free(s);
			}
			ret = 1;
			break;
		}
		else if (res > 0)
			pn = pn->left;
		else
			pn = pn->right;
	}
	if (ret == 1)
		avltree_fixup_after_remove(pt, r);

	return ret;
}

void *AVLTreeSearch(AVLTree_t avl, void *data, AVLTreeNodeCompareFunc_t compare)
{
	void *d = NULL;

	while (avl != NULL)
	{
		int res;

		res = compare(avl->data, data);
		if (res == 0)
		{
			d = avl->data;
			break;
		}
		else if (res == 1)
			avl = avl->left;
		else
			avl = avl->right;
	}

	return d;
}


void AVLTreeInOrder(AVLTree_t avl, AVLTreeNodeVisitFunc_t visit)
{
	if (avl != NULL)
	{
		AVLTreeInOrder(avl->left, visit);
		visit(avl->data);
		AVLTreeInOrder(avl->right, visit);
	}
}

void AVLTreeReInOrder(AVLTree_t avl, AVLTreeNodeVisitFunc_t visit)
{
	if (avl != NULL)
	{
		AVLTreeReInOrder(avl->right, visit);
		visit(avl->data);
		AVLTreeReInOrder(avl->left, visit);
	}
}


int AVLTreeGetNodesNum(AVLTree_t avl)
{
	int num;

	if (avl != NULL)
		num = AVLTreeGetNodesNum(avl->left) + AVLTreeGetNodesNum(avl->right) + 1;
	else
		num = 0;

	return num;
}

int AVLTreeGetHeight(AVLTree_t avl)
{
	int hl, hr, h;

	if (avl != NULL)
	{
		hl = AVLTreeGetHeight(avl->left);
		hr = AVLTreeGetHeight(avl->right);
		h = (hl > hr) ? hl : hr;
		h = h + 1;
	}
	else
		h = 0;

	return h;
}

int AVLTreeGetWidth(AVLTree_t avl)
{
	return 0;
}


void AVLTreePrint(AVLTree_t avl, AVLTreeNodeVisitFunc_t visit, int n)
{
	if (avl != NULL)
	{
		AVLTreePrint(avl->right, visit, n + 1);

		for (int i = 0; i < n; i++)
			printf(" ");
		visit(avl->data);
		printf("\n");

		AVLTreePrint(avl->left, visit, n + 1);
	}
}

/* API�� �յ� */
