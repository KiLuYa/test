/**
 * 1. This file only contains inorder threaded BiTree.
 * 2. There are many ways to achieve threaded BiTree, here is the way that cost least memory(by using the original
 *    ptr of the node other than add new ptrs into node).
 */


/* definition of node */
typedef struct node {
	char data;  //can be any data type
	unsigned char ltag, rtag;
	struct node *left;
	struct node *right;
} BiTNode, *BiTree;


/* visit a node */
void visit(BiTNode *p)
{
	printf("%c  ", p->data);
}

/**
 * Inthread BiTree.
 *
 * @param bt  BiTree
 */
void Inthread (BiTree bt)
{
	BiTNode *p, *prev;
	//stack
	BiTNode* s[STACK_SIZE];
	int top = 0;
	
	prev = NULL;
	p = bt;
	while(p!=NULL || top!=0) {
		if(p != NULL){
			top++;  //push stack
			if(top >= STACK_SIZE) {printf("stack is full\n");while(1);}
			s[top] = p;
			
			p = p->left;
		} else {
			p = s[top];  //pop stack
			top--;
			
			if(p->left == NULL) {
				p->ltag = 1;
				p->left = prev;
			} else p->ltag = 0;
			if(prev!=NULL && prev->right==NULL) {
				prev->rtag = 1;
				prev->right = p;
			} else p->rtag = 0;
			prev = p;
			
			p = p->right;
		}
	}
	prev->rtag = 1;
	prev->right = NULL;
}

/**
 * Find prev node in inthread BiTree.
 *
 * @param bt  BiTree
 */
BiTNode *InPrev(BiTNode *p) {
	BiTNode *prev;
	
	if(p->ltag == 1)
		prev = p->left;
	else
		for(prev=p->left ; prev->rtag==0 ; prev=prev->right);
	return prev;
}

/**
 * Find next node in inthread BiTree.
 *
 * @param bt  BiTree
 */
BiTNode *InNext(BiTNode *p) {
	BiTNode *next;
	
	if(p->rtag == 1)
		next = p->right;
	else
		for(next=p->right ; next->ltag==0 ; next=next->left);
	return next;
}

/**
 * Find the first node in inorder traversal.
 *
 * @param bt  BiTree
 */
BiTNode *InFirst(BiTree bt)
{
	BiTNode *p = bt;
	
	if(p==NULL) return NULL;
	while(p->ltag == 0)
		p = p->left;
	return p;
}

/**
 * Traverse inthreaded BiTree.
 *
 * @param bt  BiTree
 */
void TInOrder(BiTree bt)
{
	BiTNode *p;
	
	p = InFirst(bt);
	while(p) {
		visit(p);
		p = InNext(p);
	}
}

/**
 * Create a TBiTree by using extended preorder.
 * 'extended' means the empty child-tree count an element.
 * User should enter the element one by one.
 * Notice: the key 'enter' counts a char, the function should consume it in the end, 
 * otherwise user cannot call this function more than once.
 *
 * @param bt  ptr to BiTree
 */
void CreateTBiTree(BiTree *bt)
{
	char ch;
	BiTNode *p;
	BiTree  *pp;
	//stack
	BiTNode* s[STACK_SIZE];
	int top = 0;
	
	p = NULL;
	pp = bt;
	while(1) {
		ch = getchar();
		if(ch != '.') {
			p = malloc(sizeof(BiTNode));
			p->data = ch;
			p->ltag = p->rtag = 0;
			*pp = p;
			top++;  //push stack
			if(top >= STACK_SIZE) {printf("stack is full\n");while(1);}
			s[top] = p;
			
			pp = &(p->left);
		} else {
			*pp = NULL;
			if(top == 0)
				break;
			p = s[top--];
			pp = &(p->right);
		}
	}
	getchar();
}

/**
 * Delete TBiTree in postorder.
 * Free all BiTNode's resource.
 * 
 * @param pt  ptr to BiTree
 */
void DeleteTBiTree(BiTree *pt)
{
	BiTNode *p, *q;
	//stack
	BiTNode* s[STACK_SIZE];
	int top = 0;
	
	q = NULL;
	p = *pt;
	while(p!=NULL || top!=0) {
		if(p != NULL){
			top++;  //push stack
			if(top >= STACK_SIZE) {printf("stack is full\n");while(1);}
			s[top] = p;
			
			if(p->ltag) p = NULL;
			else p=p->left;
		} else {
			p = s[top];  //get top of stack
			if(p->rtag==1 || ((p->rtag==0) && (p->right==q))) {
				free(p);
				q = p;
				top--;
				p = NULL;
			} else p = p->right;
		}
	}
	*pt = NULL;
}

