#include "rbtree.h"
#include <stdlib.h>  //����mallco��free����


#ifndef NULL
#define NULL 0
#endif

#define  RED    0
#define  BLACK  1


/* �ӿ��� ��� */

static void *rbtree_malloc(BaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= BaseType_t

	return p;
}

static void rbtree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void rbtree_memcpy(unsigned char *d, unsigned char *s, BaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

static BaseType_t rbtree_memcmp(unsigned char *a1, unsigned char *a2, BaseType_t size)
{
	int ret = 0;

	while (size--)
	{
		if (*a1 == *a2)
		{
			a1++;
			a2++;
			continue;
		}
		if (*a1 > *a2)
		{
			ret = 1;
			break;
		}
		else
		{
			ret = -1;
			break;
		}
	}
	return ret;
}


typedef BaseType_t Stack_t;
typedef Stack_t *StackHandle_t;

static StackHandle_t StackCreate(BaseType_t n)
{
	BaseType_t *ps;

	ps = (BaseType_t *)rbtree_malloc(sizeof(BaseType_t) + n * sizeof(void *));
	if (ps != NULL)
		*ps = -1;
	
	return ps;
}

static void StackDelete(StackHandle_t s)
{
	rbtree_free((void *)s);
}

static void StackPush(StackHandle_t s, void *pn)
{
	BaseType_t *ps = s;
	void **ptr;

	ptr = (void **)(ps+1);
	(*ps)++;
	ptr[*ps] = pn;
}

static void *StackPop(StackHandle_t s)
{
	BaseType_t *ps = s;
	void **ptr;
	void *pn;

	ptr = (void **)(ps+1);
	pn = ptr[*ps];
	(*ps)--;

	return pn;
}

static void *StackGetTop(StackHandle_t s)
{
	BaseType_t *ps = s;
	void **ptr;
	void *pn;

	ptr = (void **)((unsigned char *)ps + sizeof(BaseType_t));
	pn = ptr[*ps];

	return pn;
}

static BaseType_t StackIsEmpty(StackHandle_t s)
{
	BaseType_t *ps = s;
	BaseType_t res;

	if (*ps == -1)
		res = 1;
	else
		res = 0;

	return res;
}

static BaseType_t StackGetTopIdx(StackHandle_t s)
{
	BaseType_t *ps = s;

	return *ps;
}


struct pos {
	void *p;
	BaseType_t spaces;
};


/**
 */
static RBTreeNode_t *create_node(RBTreeHandle_t rbt, void *data)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn;

	pn = rbtree_malloc(sizeof(RBTreeNode_t) + pt->nodeSize);
	if (pn != NULL)
	{
		if(data != NULL)
			rbtree_memcpy((unsigned char *)pn + sizeof(RBTreeNode_t), data, pt->nodeSize);
		pn->parent = NULL;
		pn->left = NULL;
		pn->right = NULL;
		pn->color = RED;
	}

	return pn;
}

/**
 * In avl, copy pn2's content to pn1.
 */
static void copy_content(RBTreeHandle_t rbt, RBTreeNode_t *pn1, RBTreeNode_t *pn2)
{
	RBTree_t *pt = rbt;
	BaseType_t size = pt->nodeSize;

	rbtree_memcpy((unsigned char *)pn1 + sizeof(RBTreeNode_t), (unsigned char *)pn2 + sizeof(RBTreeNode_t), size);
}


/**
 * Rotate tree left.
 * Helper function for rbtree_fixup_after_insert/rbtree_fixup_after_remove.
 * x and x->right cannot be NULL.
 */
static void rotate_left(RBTreeHandle_t rbt, RBTreeNode_t *x)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *y = x->right;

	x->right = y->left;
	if (y->left != NULL)
		y->left->parent = x;

	if (x->parent == NULL)
		pt->root = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;
	y->parent = x->parent;

	y->left = x;
	x->parent = y;
}

/**
 * Rotate tree right.
 * Helper function for rbtree_insert_fixup/rbtree_remove_fixup.
 * x and x->left cannot be NULL.
 */
static void rotate_right(RBTreeHandle_t rbt, RBTreeNode_t *x)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *y = x->left;

	x->left = y->right;
	if (y->right != NULL)
		y->right->parent = x;

	if (x->parent == NULL)
		pt->root = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;
	y->parent = x->parent;

	y->right = x;
	x->parent = y;
}

/**
 * Transplant t2 to t1 in RBTree. �ý��t1��Ψһ����t2ȥ�滻���t1��
 * t1 cannot be NULL��t2 can be NULL.
 * Helper function for RBTreeRemove.
 */
static void transplant(RBTreeHandle_t rbt, RBTreeNode_t *t1, RBTreeNode_t *t2)
{
	RBTree_t *pt = rbt;

	if (t1->parent == NULL)
	{
		pt->root = t2;
		if (t2 != NULL)
			t2->parent = NULL;
	}
	else
	{
		if (t1->parent->left == t1)
			t1->parent->left = t2;
		else
			t1->parent->right = t2;
		if (t2 != NULL)
			t2->parent = t1->parent;
	}
}

static void change_color(RBTreeNode_t *t1, RBTreeNode_t *t2)
{
	BaseType_t color;

	color = t1->color;
	t1->color = t2->color;
	t2->color = color;
}

/**
 * Fixup the rbtree to stay balance after insert a node.
 */
static void rbtree_fixup_after_insert(RBTreeHandle_t rbt, RBTreeNode_t *z)
{
	while (1)
	{
		if (z->parent == NULL)
		{
			z->color = BLACK;
			break;
		}
		else if(z->parent->color == BLACK)
		{
			break;
		}
		else  //z->parent��Ϊ�գ�������ɫΪ�죬˵��p->parent->parentһ����Ϊ�գ�������ɫΪ��
		{
			if (z->parent->parent->left == z->parent)
			{
				if (z->parent->parent->right != NULL && z->parent->parent->right->color == RED)
				{
					z->parent->color = BLACK;
					z->parent->parent->right->color = BLACK;
					z->parent->parent->color = RED;
					z = z->parent->parent;
				}
				else
				{
					if (z->parent->right == z)
					{
						z = z->parent;
						rotate_left(rbt, z);
					}
					change_color(z->parent, z->parent->parent);
					z = z->parent->parent;
					rotate_right(rbt, z);
					break;
				}
			}
			else
			{
				if (z->parent->parent->left != NULL && z->parent->parent->left->color == RED)
				{
					z->parent->color = BLACK;
					z->parent->parent->left->color = BLACK;
					z->parent->parent->color = RED;
					z = z->parent->parent;
				}
				else
				{
					if (z->parent->left == z)
					{
						z = z->parent;
						rotate_right(rbt, z);
					}
					change_color(z->parent, z->parent->parent);
					z = z->parent->parent;
					rotate_left(rbt, z);
					break;
				}
			}
		}
	}
}

/**
 * Fixup the rbtree to stay balance after remove a node.
 */
static void rbtree_fixup_after_remove(RBTreeHandle_t rbt, RBTreeNode_t *x)
{
	RBTreeNode_t *w;

	while (1)
	{
		if (x->parent == NULL)
		{
			x->color = BLACK;
			break;
		}

		if (x->color == RED)
		{
			x->color = BLACK;
			break;
		}

		if (x->parent->left == x)
		{
			w = x->parent->right;
			if (w->color == RED)
			{
				change_color(x->parent, w);
				rotate_left(rbt, x->parent);
			}
			else
			{
				if (w->left->color == BLACK && w->right->color == BLACK)
				{
					w->color = RED;
					x = x->parent;
				}
				else if(w->right->color == BLACK)
				{
					change_color(w, w->left);
					rotate_right(rbt, w);
				}
				else
				{
					w->right->color = BLACK;
					change_color(w, x->parent);
					rotate_left(rbt, x->parent);
					break;
				}
			}
		}
		else
		{
			w = x->parent->left;
			if (w->color == RED)
			{
				change_color(w, x->parent);
				rotate_right(rbt, x->parent);
			}
			else
			{
				if (w->left->color == BLACK && w->right->color == BLACK)
				{
					w->color = RED;
					x = x->parent;
				}
				else if (w->left->color == BLACK)
				{
					change_color(w, w->right);
					rotate_left(rbt, w);
				}
				else
				{
					w->left->color = BLACK;
					change_color(w, x->parent);
					rotate_right(rbt, x->parent);
					break;
				}
			}
		}
	}
}

static void rbtree_fixup_after_remove_sp(RBTreeHandle_t rbt, RBTreeNode_t *x)
{
	if (x->left != NULL)
	{
		if (x->left->color == RED)
		{
			change_color(x, x->left);
			rotate_right(rbt, x);
		}

		if (x->left->left == NULL && x->left->right == NULL)
		{
			x->left->color = RED;
			rbtree_fixup_after_remove(rbt, x);
		}	
		else
		{
			if (x->left->left == NULL && x->left->right != NULL)
			{
				change_color(x->left->right, x->left);
				rotate_left(rbt, x->left);
			}
			x->left->left->color = BLACK;
			change_color(x, x->left);
			rotate_right(rbt, x);
		}
	}
	else
	{
		if (x->right->color == RED)
		{
			change_color(x, x->right);
			rotate_left(rbt, x);
		}

		if (x->right->right == NULL && x->right->left == NULL)
		{
			x->right->color = RED;
			rbtree_fixup_after_remove(rbt, x);
		}
		else
		{
			if (x->right->right == NULL && x->right->left != NULL)
			{
				change_color(x->right->left, x->right);
				rotate_right(rbt, x->right);
			}
			x->right->right->color = BLACK;
			change_color(x, x->right);
			rotate_left(rbt, x);
		}
	}
}

/* ��̬�� �յ� */



/* API�� ��� */

RBTreeHandle_t RBTreeCreate(BaseType_t nodeSize, BaseType_t nodesNumLimit, RBTreeNodeCompareFunc_t compareFunc, RBTreeNodeVisitFunc_t visitFunc)
{
	RBTree_t *pt;

	if (nodeSize == 0)
		return NULL;

	pt = rbtree_malloc(sizeof(RBTree_t));

	if (pt != NULL)
	{
		pt->root = NULL;
		pt->nodeSize = nodeSize;
		pt->nodesNum = 0;
		pt->nodesNumLimit = nodesNumLimit;
		//pt->height = 0;
		pt->compareFunc = compareFunc;
		pt->visitFunc = visitFunc;
	}

	return pt;
}

BaseType_t RBTreeDelete(RBTreeHandle_t rbt)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn, *visited;
	StackHandle_t s;
	BaseType_t height;

	if (pt == NULL)
		return 0;

	height = RBTreeGetHeight(rbt);
	if (height == -1)
		return 0;

	s = StackCreate(height + 1);
	if (s == NULL)
		return 0;

	pn = pt->root;
	visited = NULL;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->left;
		}
		else
		{
			pn = StackGetTop(s);
			if (pn->right == NULL || pn->right == visited)
			{
				visited = pn;
				rbtree_free(pn);

				(void)StackPop(s);
				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}
	rbtree_free(pt);
	StackDelete(s);

	return 1;
}

BaseType_t RBTreeInsert(RBTreeHandle_t rbt, void *data)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t **pp, *prev, *pn, *p;
	BaseType_t res;

	if (pt == NULL)
		return 0;

	if (pt->nodesNumLimit != 0 && pt->nodesNum >= pt->nodesNumLimit)
		return 0;

	p = create_node(rbt, data);
	if (p == NULL)
		return 0;
	
	pp = &(pt->root);
	prev = NULL;
	pn = pt->root;

	while (pn != NULL)
	{
		res = pt->compareFunc((unsigned char *)pn + sizeof(RBTreeNode_t), data);
		if (res > 0)
		{
			pp = &(pn->left);
			prev = pn;
			pn = pn->left;
		}
		else
		{
			pp = &(pn->right);
			prev = pn;
			pn = pn->right;
		}
	}
	
	p->parent = prev;
	*pp = p;

	p->color = RED;
	rbtree_fixup_after_insert(rbt, p);

	pt->nodesNum++;

	return 1;
}

BaseType_t RBTreeRemove(RBTreeHandle_t rbt, void *data)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn, *r, *s;
	BaseType_t res, ret;
	BaseType_t deletedColor;
	BaseType_t flag;

	if (pt == NULL)
		return 0;

	pn = pt->root;
	ret = 0;
	r = NULL;
	flag = 0;

	while (pn != NULL)
	{
		res = pt->compareFunc((unsigned char *)pn + sizeof(RBTreeNode_t), data);
		if (res == 0)
		{
			if (pn->left == NULL)
			{
				if (pn->right == NULL)
				{
					r = pn->parent;
					flag = 1;
				}
				else
					r = pn->right;
				deletedColor = pn->color;

				transplant(rbt, pn, pn->right);
				rbtree_free(pn);
			}
			else
			{
				s = pn->left;
				while (s->right != NULL)
					s = s->right;
				
				if (s->left == NULL)
				{
					r = s->parent;
					flag = 1;
				}
				else
					r = s->left;
				deletedColor = s->color;

				transplant(rbt, s, s->left);
				copy_content(rbt, pn, s);
				rbtree_free(s);
			}
			ret = 1;
			break;
		}
		else if (res > 0)
			pn = pn->left;
		else
			pn = pn->right;
	}
	if (ret == 1)
	{
		if (r != NULL && deletedColor == BLACK)
		{
			if (flag == 1)
				rbtree_fixup_after_remove_sp(rbt, r);
			else
				rbtree_fixup_after_remove(rbt, r);
		}
		pt->nodesNum--;
	}

	return ret;
}

void *RBTreeSearch(RBTreeHandle_t rbt, void *data)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn;
	BaseType_t res;
	void *ret;

	if (pt == NULL)
		return NULL;

	pn = pt->root;
	ret = NULL;

	while (pn != NULL)
	{
		res = pt->compareFunc((unsigned char *)pn + sizeof(RBTreeNode_t), data);
		if (res == 0)
		{
			ret = (unsigned char *)pn + sizeof(RBTreeNode_t);
			break;
		}
		else if (res > 0)
			pn = pn->left;
		else
			pn = pn->right;
	}

	return ret;
}


RBTreeHandle_t RBTreeCopy(RBTreeHandle_t rbt)
{
	RBTree_t *pst = rbt;
	RBTree_t *pdt;
	StackHandle_t s;
	RBTreeNode_t *pn, *pn1, **prev, *parent;
	BaseType_t res;
	BaseType_t height;

	if (pst == NULL)
		return NULL;

	height = RBTreeGetHeight(rbt);
	if (height == -1)
		return NULL;

	pdt = rbtree_malloc(sizeof(RBTree_t));
	if (pdt == NULL)
		return NULL;

	s = StackCreate(2*height + 1);
	if (s == NULL)
	{
		rbtree_free(pdt);
		return NULL;
	}

	pdt->root = NULL;
	pdt->nodeSize = pst->nodeSize;
	pdt->nodesNum = pst->nodesNum;
	pdt->nodesNumLimit = pst->nodesNumLimit;
	//pdt->height = pst->height;
	pdt->compareFunc = pst->compareFunc;
	pdt->visitFunc = pst->visitFunc;

	pn = pst->root;
	prev = &(pdt->root);
	parent = NULL;
	res = 1;
	
	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			pn1 = create_node(rbt, (unsigned char *)pn+sizeof(RBTreeNode_t));
			if (pn1 == NULL)
			{
				res = 0;
				break;
			}
			*prev = pn1;
			pn1->parent = parent;
			pn1->color = pn->color;

			prev = &(pn1->left);
			parent = pn1;
			StackPush(s, pn);
			StackPush(s, pn1);
			pn = pn->left;
		}
		else
		{
			*prev = NULL;
			pn1 = StackPop(s);
			pn = StackPop(s);
			prev = &(pn1->right);
			parent = pn1;
			pn = pn->right;
		}
	}
	if (res == 1)
		*prev = NULL;
	else
	{
		res = RBTreeDelete(pdt);
		if(res == 1)
			pdt = NULL;
		else
		{
			printf("warning: memory leak !!!\n");
			pdt = NULL;
			//while(1);
		}
	}

	StackDelete(s);

	return pdt;
}

BaseType_t RBTreeInOrder(RBTreeHandle_t rbt, void *arg)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn;
	StackHandle_t s;
	BaseType_t height;

	if (pt == NULL)
		return 0;

	height = RBTreeGetHeight(rbt);
	if (height == -1)
		return 0;

	s = StackCreate(height + 1);
	if (s == NULL)
		return 0;

	pn = pt->root;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->left;
		}
		else
		{
			pn = StackPop(s);
			pt->visitFunc((unsigned char *)pn+sizeof(RBTreeNode_t), arg);
			pn = pn->right;
		}
	}

	StackDelete(s);

	return 1;
}

BaseType_t RBTreeReInOrder(RBTreeHandle_t rbt, void *arg)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn;
	StackHandle_t s;
	BaseType_t height;

	if (pt == NULL)
		return 0;

	height = RBTreeGetHeight(rbt);
	if (height == -1)
		return 0;

	s = StackCreate(height + 1);
	if (s == NULL)
		return 0;

	pn = pt->root;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->right;
		}
		else
		{
			pn = StackPop(s);
			pt->visitFunc((unsigned char *)pn + sizeof(RBTreeNode_t), arg);
			pn = pn->left;
		}
	}

	StackDelete(s);

	return 1;
}

BaseType_t RBTreeGetNodesNum(RBTreeHandle_t rbt)
{
	RBTree_t *pt = rbt;
	BaseType_t ret;

	if (pt == NULL)
		ret = -1;
	else
		ret = pt->nodesNum;

	return ret;
}

BaseType_t RBTreeGetHeight(RBTreeHandle_t rbt)
{
	static BaseType_t maxHeight = 100;

	RBTree_t *pt = rbt;
	RBTreeNode_t *pn, *visited;
	StackHandle_t s;
	BaseType_t height, hig;

	if (pt == NULL)
		return -1;

	s = StackCreate(maxHeight + 1);
	if (s == NULL)
		return -1;

	pn = pt->root;
	visited = NULL;
	height = 0;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->left;
		}
		else
		{
			pn = StackGetTop(s);
			if (pn->right == NULL || pn->right == visited)
			{
				visited = pn;
				hig = StackGetTopIdx(s) + 1;
				if (hig > height)
					height = hig;

				(void)StackPop(s);
				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}
	StackDelete(s);

	return height;
}

BaseType_t RBTreeGetWidth(RBTreeHandle_t rbt)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn, *visited;
	StackHandle_t s;
	BaseType_t wid, *ptr;
	BaseType_t i;
	BaseType_t height;

	if (pt == NULL)
		return -1;

	height = RBTreeGetHeight(rbt);
	if (height == -1)
		return -1;
	
	if (height == 0)
		return 0;

	s = StackCreate(height + 1);
	if (s == NULL)
		return -1;

	ptr = rbtree_malloc(height * sizeof(BaseType_t));
	if (ptr == NULL)
	{
		StackDelete(s);
		return -1;
	}
	for (i = 0; i < height; i++)
		ptr[i] = 0;

	pn = pt->root;
	visited = NULL;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->left;
		}
		else
		{
			pn = StackGetTop(s);
			if (pn->right == NULL || pn->right == visited)
			{
				ptr[StackGetTopIdx(s)]++;
				visited = pn;

				(void)StackPop(s);
				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}
	wid = 0;
	for (i = 0; i < height; i++)
	{
		if (ptr[i] > wid)
			wid = ptr[i];
	}

	StackDelete(s);
	rbtree_free(ptr);

	return wid;
}

void RBTreeSetNodeCompareFunc(RBTreeHandle_t rbt, RBTreeNodeCompareFunc_t compareFunc)
{
	RBTree_t *pt = rbt;

	if (pt != NULL)
		pt->compareFunc = compareFunc;
}

void RBTreeSetNodeVisitFunc(RBTreeHandle_t rbt, RBTreeNodeVisitFunc_t visitFunc)
{
	RBTree_t *pt = rbt;

	if (pt != NULL)
		pt->visitFunc = visitFunc;
}

BaseType_t RBTreePrint(RBTreeHandle_t rbt, BaseType_t dir)
{
	RBTree_t *pt = rbt;
	RBTreeNode_t *pn;
	StackHandle_t s;
	struct pos *pos;
	BaseType_t i, num;
	BaseType_t j, max_line, k, m;
	BaseType_t height;

	if (pt == NULL)
		return 0;

	height = RBTreeGetHeight(rbt);
	if (height == -1)
		return 0;
	
	s = StackCreate(2*height + 1);
	if (s == NULL)
		return 0;

	pos = rbtree_malloc(pt->nodesNum * sizeof(struct pos));
	if (pos == NULL)
	{
		StackDelete(s);
		return 0;
	}

	pn = pt->root;
	num = 0;
	k = 0;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			StackPush(s, (void *)k);
			pn = pn->right;
			k++;
		}
		else
		{
			k = (BaseType_t)StackPop(s);
			pn = StackPop(s);

			pos[num].p = (unsigned char *)pn + sizeof(RBTreeNode_t);
			pos[num].spaces = k;
			num++;
			pn = pn->left;
			k++;
		}
	}

	if (dir == 0)
	{
		for (i = 0; i < num; i++)
		{
			for (j = 0; j < pos[i].spaces; j++)
				printf(" ");
			printf("%d\n", *(int *)(pos[i].p));
		}
	}
	else
	{
		max_line = 0;
		for (i = 0; i < num; i++)
			if (pos[i].spaces > max_line)
				max_line = pos[i].spaces;
		for (i = 0; i <= max_line; i++)
		{
			k = num;
			for (j = num - 1; j >= 0; j--)
			{
				if (pos[j].spaces == i)
				{
					for (m = 0; m < k - j - 1; m++)
						printf(" ");
					printf("%d", *(int *)(pos[j].p));
					k = j;
				}
			}
			printf("\n");
		}
	}

	StackDelete(s);
	rbtree_free(pos);

	return 1;
}

/* API�� �յ� */
