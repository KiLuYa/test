#include "queue.h"
#include <stdlib.h>  //����C���malloc��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *queue_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= UBaseType_t

	return p;
}

static void queue_free(void *pq)
{
	free(pq);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void queue_memcpy(unsigned char *d, unsigned char *s, UBaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

/* ��̬�� �յ� */



/* API�� ��� */

QueueHandle_t QueueCreate(UBaseType_t nodeSize, UBaseType_t length)
{
	Queue_t *pq;

	if (nodeSize == 0 || length == 0)
		return NULL;

	pq = (Queue_t *)queue_malloc((UBaseType_t)sizeof(Queue_t));
	
	if (pq != NULL)
	{
		pq->head = NULL;
		pq->tail = NULL;
		pq->nodeSize = nodeSize;
		pq->length = length;
		pq->messages = 0;
	}

	return pq;
}

void QueueDelete(QueueHandle_t q)
{
	Queue_t *pq = q;
	QueueNode_t *pNode, *pNextNode;

	if (pq == NULL)
		return;

	pNode = pq->head;
	while (pNode != NULL)
	{
		pNextNode = pNode->next;
		queue_free((void *)pNode);
		pNode = pNextNode;
	}
	queue_free((void *)pq);
}

BaseType_t QueueSend(QueueHandle_t q, void *pMessage, BaseType_t sendToBack)
{
	Queue_t *pq = q;
	BaseType_t res;
	QueueNode_t *pNode;

	if (pq == NULL)
		return 0;

	if (pq->messages == pq->length)
		res = 0;
	else
	{
		if (pq->messages == 0)
		{
			pNode = (QueueNode_t *)queue_malloc((UBaseType_t)sizeof(QueueNode_t) + pq->nodeSize);
			if (pNode != NULL)
			{
				queue_memcpy((unsigned char *)pNode + sizeof(QueueNode_t), (unsigned char *)pMessage, pq->nodeSize);
				pNode->next = NULL;
				pq->head = pq->tail = pNode;
				res = 1;
			}
			else
				res = 0;
		}
		else
		{
			if(sendToBack)
			{
				pNode = (QueueNode_t *)queue_malloc((UBaseType_t)sizeof(QueueNode_t) + pq->nodeSize);
				if (pNode != NULL)
				{
					queue_memcpy((unsigned char *)pNode + sizeof(QueueNode_t), (unsigned char *)pMessage, pq->nodeSize);
					pNode->next = NULL;
					pq->tail->next = pNode;
					pq->tail = pNode;
					res = 1;
				}
				else
					res = 0;
			}
			else
			{
				pNode = (QueueNode_t *)queue_malloc((UBaseType_t)sizeof(QueueNode_t) + pq->nodeSize);
				if (pNode != NULL)
				{
					queue_memcpy((unsigned char *)pNode + sizeof(QueueNode_t), (unsigned char *)pMessage, pq->nodeSize);
					pNode->next = pq->head;
					pq->head = pNode;
					res = 1;
				}
				else
					res = 0;
			}
		}
		pq->messages++;
	}

	return res;
}

BaseType_t QueueReceive(QueueHandle_t q, void *pBuf)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return 0;
	
	if (pq->messages == 0)
		res = 0;
	else
	{
		queue_memcpy((unsigned char *)pBuf, (unsigned char *)pq->head + sizeof(QueueNode_t), pq->nodeSize);
		pq->head = pq->head->next;
		if (pq->head == NULL)
			pq->tail = NULL;
		pq->messages--;
		res = 1;
	}
	
	return res;
}

BaseType_t QueuePeek(QueueHandle_t q, void *pBuf)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return 0;

	if (pq->messages == 0)
		res = 0;
	else
	{
		queue_memcpy((unsigned char *)pBuf, (unsigned char *)pq->head + sizeof(QueueNode_t), pq->nodeSize);
		res = 1;
	}

	return res;
}

BaseType_t QueueIsEmpty(QueueHandle_t q)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return -1;

	if (pq->messages == 0)
		res = 1;
	else
		res = 0;

	return res;
}

BaseType_t QueueIsFull(QueueHandle_t q)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return -1;

	if (pq->messages == pq->length)
		res = 1;
	else
		res = 0;

	return res;
}

/* API�� �յ� */
