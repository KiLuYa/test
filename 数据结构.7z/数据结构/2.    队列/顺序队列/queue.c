#include "queue.h"
#include <stdlib.h>  //����C���malloc��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *queue_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= UBaseType_t

	return p;
}

static void queue_free(void *pq)
{
	free(pq);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void queue_memcpy(unsigned char *d, unsigned char *s, UBaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

/* ��̬�� �յ� */



/* API�� ��� */

QueueHandle_t QueueCreate(UBaseType_t nodeSize, UBaseType_t length)
{
	Queue_t *pq;
	UBaseType_t size;

	if (nodeSize == 0 || length == 0)
		return NULL;

	size = (UBaseType_t)sizeof(Queue_t) + nodeSize * length;
	pq = (Queue_t *)queue_malloc(size);
	
	if (pq != NULL)
	{
		pq->length = length;
		pq->nodeSize = nodeSize;
		pq->head = (unsigned char *)pq + sizeof(Queue_t);
		pq->tail = pq->head + length * nodeSize;
		pq->messages = 0;
		pq->write = pq->head;
		pq->read = pq->head;
	}

	return pq;
}

void QueueDelete(QueueHandle_t q)
{
	Queue_t *pq = q;

	if (pq == NULL)
		return;

	queue_free((void *)pq);
}

BaseType_t QueueSend(QueueHandle_t q, void *pMessage, BaseType_t sendToBack)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return 0;

	if (pq->messages >= pq->length)
		res = 0;
	else
	{
		if (pq->messages == 0)
		{
			queue_memcpy(pq->write, (unsigned char *)pMessage, pq->nodeSize);
			pq->write += pq->nodeSize;
			if (pq->write == pq->tail)
				pq->write = pq->head;
		}
		else
		{
			if(sendToBack)
			{
				queue_memcpy(pq->write, (unsigned char *)pMessage, pq->nodeSize);
				pq->write += pq->nodeSize;
				if (pq->write == pq->tail)
					pq->write = pq->head;
			}
			else
			{
				if (pq->read == pq->head)
					pq->read = pq->tail - pq->nodeSize;
				else
					pq->read -= pq->nodeSize;
				queue_memcpy(pq->read, (unsigned char *)pMessage, pq->nodeSize);
			}
		}
		pq->messages++;
		res = 1;
	}

	return res;
}

BaseType_t QueueReceive(QueueHandle_t q, void *pBuf)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return 0;
	
	if (pq->messages == 0)
		res = 0;
	else
	{
		queue_memcpy((unsigned char *)pBuf, pq->read, pq->nodeSize);
		pq->read += pq->nodeSize;
		if (pq->read == pq->tail)
			pq->read = pq->head;

		pq->messages--;
		res = 1;
	}
	
	return res;
}

BaseType_t QueuePeek(QueueHandle_t q, void *pBuf)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return 0;

	if (pq->messages == 0)
		res = 0;
	else
	{
		queue_memcpy((unsigned char *)pBuf, pq->read, pq->nodeSize);
		res = 1;
	}

	return res;
}

BaseType_t QueueIsEmpty(QueueHandle_t q)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return -1;

	if (pq->messages == 0)
		res = 1;
	else
		res = 0;

	return res;
}

BaseType_t QueueIsFull(QueueHandle_t q)
{
	Queue_t *pq = q;
	BaseType_t res;

	if (pq == NULL)
		return -1;

	if (pq->messages == pq->length)
		res = 1;
	else
		res = 0;

	return res;
}

/* API�� �յ� */
