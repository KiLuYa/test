
#include <stdio.h>

#include "./DataStructure/stack.h"


int main(void)
{
	StackHandle_t s;
	int n, m;
	int res;

	s = StackCreate(sizeof(unsigned int), 3);
	printf("create stack %x\n", s);

	while (1)
	{
		scanf("%d %d", &n, &m);
		switch (n)
		{
		case 0:
			res = StackPush(s, (unsigned char*)&m);
			if (res == 0)
				printf("stack is full\n");
			else
				printf("push %d into stack\n", m);
			break;
		case 1:
			res = StackPop(s, &m);
			if (res == 0)
				printf("stack is empty\n");
			else
				printf("pop %d out of stack\n", m);
			break;
		case 2:
			res = StackGetTop(s, &m);
			if (res == 0)
				printf("stack is empty\n");
			else
				printf("get top of stack: %d\n", m);
			break;
		case 3:
			res = StackIsEmpty(s);
			printf("stack is empty? ans: %d\n", res);
			break;
		case 4:
			res = StackIsFull(s);
			printf("stack is full? ans: %d\n", res);
			break;
		case 5:
			printf("delete stack %x\n", s);
			StackDelete(s);
			s = StackCreate(sizeof(unsigned int), 3);
			printf("create stack %x\n", s);
			break;
		default:
			break;
		}
	}
}

