
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "./DataStructure/rbtree.h"


static void visitNode(void *node_arg, void *user_arg)
{
	(void)user_arg;

	printf("%d ", *(int *)(node_arg));
}

static BaseType_t compareNode(void *node_arg, void *user_arg)
{
	BaseType_t ret;
	int node, user;

	node = *((int *)node_arg);
	user = *((int *)user_arg);

	if (node == user)
		ret = 0;
	else if (node > user)
		ret = 1;
	else
		ret = -1;

	return ret;
}


int main(void)
{
	RBTreeHandle_t rbt, rbt2=NULL;
	BaseType_t res;
	int n, m;
	int *pint;

	rbt = RBTreeCreate(sizeof(int), 0, compareNode, visitNode);
	
	while (1)
	{
		scanf("%d %d", &n, &m);

		switch (n)
		{
		case 0:
			res = RBTreeInsert(rbt, &m);
			if (res)
				printf("insert %d into rbt\n", m);
			else
				printf("insert %d fail\n", m);
			break;
		case 1:
			res = RBTreeRemove(rbt, &m);
			if (res)
				printf("remove %d from rbt\n", m);
			else
				printf("remove %d fail\n", m);
			break;
		case 2:
			pint = RBTreeSearch(rbt, &m);
			if (pint != NULL)
				printf("search %d, find %d\n", m, *(int *)pint);
			else
				printf("search %d fail\n", m);
			break;
		case 3:
			RBTreeInOrder(rbt, NULL);
			printf("\n");
			break;
		case 4:
			RBTreeReInOrder(rbt, NULL);
			printf("\n");
			break;
		case 5:
			printf("rbt's nodesNum: %d\n", RBTreeGetNodesNum(rbt));
			break;
		case 6:
			printf("rbt's height: %d\n", RBTreeGetHeight(rbt));
			break;
		case 7:
			printf("rbt's width:  %d\n", RBTreeGetWidth(rbt));
			break;
		case 8:
			RBTreePrint(rbt, 0);
			printf("\n");
			break;
		case 9:
			RBTreePrint(rbt, 1);
			printf("\n");
			break;
		case 10:
			printf("Delete rbt: %x\n", rbt);
			RBTreeDelete(rbt);
			rbt = RBTreeCreate(sizeof(int), 0, compareNode, visitNode);
			printf("Create rbt: %x\n", rbt);
			break;
		case 11:
			printf("copy rbt to rbt2, after copy:\n");
			RBTreeDelete(rbt2);
			rbt2 = RBTreeCopy(rbt);
			if (rbt2 != NULL)
			{
				RBTreePrint(rbt2, 0);
				printf("\n");
			}
			else
				printf("copy fail\n");
			break;
		default:
			break;
		}
	}
}

