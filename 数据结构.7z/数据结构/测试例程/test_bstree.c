
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "./DataStructure/bstree.h"


static void visitNode(void *node_arg, void *user_arg)
{
	(void)user_arg;

	printf("%d ", *(int *)(node_arg));
}

static BaseType_t compareNode(void *node_arg, void *user_arg)
{
	BaseType_t ret;
	int node, user;

	node = *((int *)node_arg);
	user = *((int *)user_arg);

	if (node == user)
		ret = 0;
	else if (node > user)
		ret = 1;
	else
		ret = -1;

	return ret;
}


int main(void)
{
	BSTreeHandle_t bst, bst2 = NULL;
	BaseType_t res;
	int n, m;
	int *pint;

	bst = BSTreeCreate(sizeof(int), 0, compareNode, visitNode);

	while (1)
	{
		scanf("%d %d", &n, &m);

		switch (n)
		{
		case 0:
			res = BSTreeInsert(bst, &m);
			if (res)
				printf("insert %d into bst\n", m);
			else
				printf("insert %d fail\n", m);
			break;
		case 1:
			res = BSTreeRemove(bst, &m);
			if (res)
				printf("remove %d from bst\n", m);
			else
				printf("remove %d fail\n", m);
			break;
		case 2:
			pint = BSTreeSearch(bst, &m);
			if (pint != NULL)
				printf("search %d, find %d\n", m, *(int *)pint);
			else
				printf("search %d fail\n", m);
			break;
		case 3:
			BSTreeInOrder(bst, NULL);
			printf("\n");
			break;
		case 4:
			BSTreeReInOrder(bst, NULL);
			printf("\n");
			break;
		case 5:
			printf("bst's nodesNum: %d\n", BSTreeGetNodesNum(bst));
			break;
		case 6:
			printf("bst's height: %d\n", BSTreeGetHeight(bst));
			break;
		case 7:
			printf("bst's width:  %d\n", BSTreeGetWidth(bst));
			break;
		case 8:
			BSTreePrint(bst, 0);
			printf("\n");
			break;
		case 9:
			BSTreePrint(bst, 1);
			printf("\n");
			break;
		case 10:
			printf("Delete bst: %x\n", bst);
			BSTreeDelete(bst);
			bst = BSTreeCreate(sizeof(int), 0, compareNode, visitNode);
			printf("Create bst: %x\n", bst);
			break;
		case 11:
			printf("copy bst to bst2, after copy:\n");
			BSTreeDelete(bst2);
			bst2 = BSTreeCopy(bst);
			if (bst2 != NULL)
			{
				BSTreePrint(bst2, 0);
				printf("\n");
			}
			else
				printf("copy fail\n");
			break;
		default:
			break;
		}
	}
}

