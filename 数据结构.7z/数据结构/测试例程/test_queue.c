
#include <stdio.h>

#include "./DataStructure/queue.h"


int main(void)
{
	QueueHandle_t q;
	int n, m;
	int res;

	q = QueueCreate(sizeof(unsigned int), 3);
	printf("create queue %x\n", q);

	while (1)
	{
		scanf("%d %d", &n, &m);
		switch (n)
		{
		case 0:
			res = QueueSend(q, (unsigned char*)&m, 1);
			if (res == 0)
				printf("queue is full\n");
			else
				printf("send %d into queue back\n", m);
			break;
		case 1:
			res = QueueSend(q, (unsigned char*)&m, 0);
			if (res == 0)
				printf("queue is full\n");
			else
				printf("send %d into queue front\n", m);
			break;
		case 2:
			res = QueueReceive(q, &m);
			if (res == 0)
				printf("queue is empty\n");
			else
				printf("take %d out of queue\n", m);
			break;
		case 3:
			res = QueuePeek(q, &m);
			if (res == 0)
				printf("queue is empty\n");
			else
				printf("get first of queue: %d\n", m);
			break;
		case 4:
			res = QueueIsEmpty(q);
			printf("queue is empty? ans: %d\n", res);
			break;
		case 5:
			res = QueueIsFull(q);
			printf("queue is full? ans: %d\n", res);
			break;
		case 6:
			printf("delete queue %x\n", q);
			QueueDelete(q);
			q = QueueCreate(sizeof(unsigned int), 3);
			printf("create queue %x\n", q);
			break;
		default:
			break;
		}
	}
}

