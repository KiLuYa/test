
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "./DataStructure/bitree.h"


static void visitNode(BitreeNode_t *pn, void *arg)
{
	(void)arg;

	printf("%c ", *((char *)pn + sizeof(BitreeNode_t)));
}


static void *bitree_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= BitreeNodeSize_t

	return p;
}

static void createBitree(BitreeNode_t **pn, int *n)
{
	char c;

	scanf("%c", &c);
	if (c != '.')
	{
		(*n)++;
		BitreeNode_t *p = bitree_malloc(sizeof(BitreeNode_t) + 1);
		*((char *)p + sizeof(BitreeNode_t)) = c;
		*pn = p;
		createBitree(&(p->left), n);
		createBitree(&(p->right), n);
	}
	else
		*pn = NULL;
}

/**
 * Create a BiTree by using extended preorder.
 * 'extended' means the empty child-tree count an element.
 * User should enter the element one by one.
 * Notice: the key 'enter' counts a char, the function should consume it in the end,
 * otherwise user cannot call this function more than once.
 */
static BitreeHandle_t BitreeCreateExt(void)
{
	Bitree_t *pt;
	char c;
	int n = 0;

	pt = BitreeCreate(1, 0);
	createBitree(&(pt->root), &n);
	pt->nodesNum = n;

	scanf("%c", &c);
	return pt;
}


int main(void)
{
	BitreeHandle_t bt, bt2;
	int n;
	char cc;

	bt = BitreeCreateExt();
	printf("bt:\n");
	BitreePrint(bt, 1);
	bt2 = BitreeCreateExt();
	printf("bt2:\n");
	BitreePrint(bt2, 1);

	while (1)
	{
		scanf("%d", &n);

		switch (n)
		{
		case 0:
			BitreePreOrder(bt, visitNode, NULL);
			printf("\n");
			break;
		case 1:
			BitreeInOrder(bt, visitNode, NULL);
			printf("\n");
			break;
		case 2:
			BitreePostOrder(bt, visitNode, NULL);
			printf("\n");
			break;
		case 3:
			BitreeLayerOrder(bt, visitNode, NULL);
			printf("\n");
			break;
		case 4:
			printf("bt's nodesNum: %d\n", BitreeGetNodesNum(bt));
			break;
		case 5:
			printf("bt's terminal nodesNum: %d\n", BitreeGetTerminalNodesNum(bt));
			break;
		case 6:
			printf("bt's height: %d\n", BitreeGetHeight(bt));
			break;
		case 7:
			printf("bt's width:  %d\n", BitreeGetWidth(bt));
			break;
		case 8:
			BitreePrint(bt, 0);
			printf("\n");
			break;
		case 9:
			BitreePrint(bt, 1);
			printf("\n");
			break;
		case 10:
			BitreeSwitchChildren(bt);
			printf("After switch children:\n");
			BitreePrint(bt, 1);
			printf("\n");
			break;
		case 11:
			printf("bt and bt2 is similar?  ans: %d\n", BitreeIsSimilar(bt, bt2));
			break;
		case 12:
			printf("bt and bt2 is same?  ans: %d\n", BitreeIsSame(bt, bt2));
			break;
		case 13:
			printf("Delete bt: %x\n", bt);
			BitreeDelete(bt);
			scanf("%c", &cc);
			printf("Enter nodes:\n");
			bt = BitreeCreateExt();
			printf("Create Bitree: %x\n", bt);
			break;
		case 14:
			printf("copy bt to bt2, after copy:\n");
			BitreeDelete(bt2);
			bt2 = BitreeCopy(bt);
			BitreePrint(bt2, 1);
			printf("\n");
			break;
		default:
			break;
		}
	}
}

