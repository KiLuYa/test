
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "./DataStructure/avltree.h"


static void visitNode(void *node_arg, void *user_arg)
{
	(void)user_arg;

	printf("%d ", *(int *)(node_arg));
}

static BaseType_t compareNode(void *node_arg, void *user_arg)
{
	BaseType_t ret;
	int node, user;

	node = *((int *)node_arg);
	user = *((int *)user_arg);

	if (node == user)
		ret = 0;
	else if (node > user)
		ret = 1;
	else
		ret = -1;

	return ret;
}


int main(void)
{
	AVLTreeHandle_t avl, avl2=NULL;
	BaseType_t res;
	int n, m;
	int *pint;

	avl = AVLTreeCreate(sizeof(int), 0, compareNode, visitNode);
	
	while (1)
	{
		scanf("%d %d", &n, &m);

		switch (n)
		{
		case 0:
			res = AVLTreeInsert(avl, &m);
			if (res)
				printf("insert %d into avl\n", m);
			else
				printf("insert %d fail\n", m);
			break;
		case 1:
			res = AVLTreeRemove(avl, &m);
			if (res)
				printf("remove %d from avl\n", m);
			else
				printf("remove %d fail\n", m);
			break;
		case 2:
			pint = AVLTreeSearch(avl, &m);
			if (pint != NULL)
				printf("search %d, find %d\n", m, *(int *)pint);
			else
				printf("search %d fail\n", m);
			break;
		case 3:
			AVLTreeInOrder(avl, NULL);
			printf("\n");
			break;
		case 4:
			AVLTreeReInOrder(avl, NULL);
			printf("\n");
			break;
		case 5:
			printf("avl's nodesNum: %d\n", AVLTreeGetNodesNum(avl));
			break;
		case 6:
			printf("avl's height: %d\n", AVLTreeGetHeight(avl));
			break;
		case 7:
			printf("avl's width:  %d\n", AVLTreeGetWidth(avl));
			break;
		case 8:
			AVLTreePrint(avl, 0);
			printf("\n");
			break;
		case 9:
			AVLTreePrint(avl, 1);
			printf("\n");
			break;
		case 10:
			printf("Delete avl: %x\n", avl);
			AVLTreeDelete(avl);
			avl = AVLTreeCreate(sizeof(int), 0, compareNode, visitNode);
			printf("Create avl: %x\n", avl);
			break;
		case 11:
			printf("copy avl to avl2, after copy:\n");
			AVLTreeDelete(avl2);
			avl2 = AVLTreeCopy(avl);
			if (avl2 != NULL)
			{
				AVLTreePrint(avl2, 0);
				printf("\n");
			}
			else
				printf("copy fail\n");
			break;
		default:
			break;
		}
	}
}

