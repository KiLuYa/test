#include "ringbuf.h"
#include "string.h"  //����memcpy����


RingbufSize_t ringbuf_write(ringbuf_t *rb, unsigned char *buf, RingbufSize_t len)
{
	RingbufSize_t tot_wlen = 0;

	if (ringbuf_free(rb) >= len)
	{
		tot_wlen = len;
		while (len--)
			ringbuf_put(rb, *buf++);
	}

	return tot_wlen;
}

RingbufSize_t ringbuf_read(ringbuf_t *rb, unsigned char *buf, RingbufSize_t max_len)
{
	RingbufSize_t len, cpy_len;
	unsigned char wrap;
	
	len = ringbuf_linear_read_length(rb);
	
	if(max_len==0 || len==0)
		return 0;
	
	wrap = ringbuf_len(rb) > len;
	if (max_len < len)
		len = max_len;
	memcpy(buf, ringbuf_get_ptr(rb), len);
	cpy_len = len;
	ringbuf_advance_get_idx(rb, len);
	
	if(wrap && max_len>len) {
		buf += len;
		max_len -= len;
		len = ringbuf_linear_read_length(rb);
		if (max_len < len)
			len = max_len;
		memcpy(buf, ringbuf_get_ptr(rb), len);
		ringbuf_advance_get_idx(rb, len);
		cpy_len += len;
	}
	return cpy_len;
}
