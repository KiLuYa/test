#include "ringbuf.h"
#include <string.h>  //����memcpy����
//#include <stdlib.h>  //����C���malloc��free����


#define ringbufTRUE   1
#define ringbufFALSE  0

#ifndef NULL
#define NULL 0
#endif


/* need to implement */
static void *ringbuf_malloc(RingbufSize_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= QueueSize_t

	return p;
}

static void ringbuf_free(void *pr)
{
	free(pr);
}
/* need to implement */


Ringbuf_t *RingbufCreate(RingbufSize_t size)
{
	Ringbuf_t *pr;
	RingbufSize_t tot_size;

	tot_size = sizeof(Ringbuf_t) + size + 1;  //Ԥ��һ���ֽڣ�������ֹ��дָ���غϲ���������
	pr = ringbuf_malloc(tot_size);

	if (pr != NULL)
	{
		pr->pHead = (unsigned char *)pr + sizeof(Ringbuf_t);
		pr->size = size;
		pr->write = 0;
		pr->read = 0;
	}

	return pr;
}

void RingbufDelete(Ringbuf_t *pr)
{
	ringbuf_free((void *)pr);
}

RingbufSize_t RingbufWrite(Ringbuf_t *pr, unsigned char *data, RingbufSize_t len, int type)
{
	RingbufSize_t wlen;
	RingbufSize_t tot_wlen = 0;

	if (type == 0)
	{
		if (pr->read <= pr->write)
		{
			wlen = pr->size + 1 - pr->write;
			if (len < wlen)
				wlen = len;
			memcpy(pr->pHead + pr->write, data, wlen);
			tot_wlen = wlen;
			len -= wlen;
			pr->write += wlen;
			if (pr->write == pr->size + 1)
				pr->write = 0;
			if (len != 0)
			{
				if (pr->read > 0)
				{
					wlen = pr->read;
					if (len < wlen)
						wlen = len;
					memcpy(pr->pHead, data + tot_wlen, wlen);
					tot_wlen += wlen;
					pr->write += wlen;
				}
			}
			if (pr->write == pr->read)
			{
				if (pr->write == 0)
					pr->write = pr->size;
				else
					pr->write--;
				tot_wlen--;
			}
		}
		else
		{
			wlen = pr->read - pr->write - 1;
			if (len < wlen)
				wlen = len;
			memcpy(pr->pHead + pr->write, data, wlen);
			tot_wlen = wlen;
			pr->write += wlen;
		}
	}
	else
	{
		if (pr->read <= pr->write)
		{
			wlen = pr->size + 1 - (pr->write - pr->read) - 1;
			if (wlen >= len)
			{
				wlen = pr->size + 1 - pr->write;
				if (len < wlen)
					wlen = len;
				memcpy(pr->pHead + pr->write, data, wlen);
				tot_wlen = wlen;
				len -= wlen;
				pr->write += wlen;
				if (pr->write == pr->size + 1)
					pr->write = 0;
				if (len != 0)
				{
					wlen = len;
					memcpy(pr->pHead, data + tot_wlen, wlen);
					tot_wlen += wlen;
					pr->write += wlen;
				}
			}
			else
				tot_wlen = 0;
		}
		else
		{
			wlen = pr->read - pr->write - 1;
			if (wlen >= len)
			{
				memcpy(pr->pHead + pr->write, data, wlen);
				tot_wlen = wlen;
				pr->write += wlen;
			}
			else
				tot_wlen = 0;
		}
	}
	return tot_wlen;
}

RingbufSize_t RingbufRead(Ringbuf_t *pr, unsigned char *data, RingbufSize_t len)
{
	RingbufSize_t rlen;
	RingbufSize_t tot_rlen = 0;

	if (pr->write < pr->read)
	{
		rlen = pr->size + 1 - pr->read;
		if (len < rlen)
			rlen = len;
		memcpy(data, pr->pHead + pr->read, rlen);
		tot_rlen = rlen;
		len -= rlen;
		pr->read += rlen;
		if (pr->read = pr->size + 1)
			pr->read = 0;
		if (len != 0)
		{
			rlen = pr->write;
			if (len < rlen)
				rlen = len;
			memcpy(data + tot_rlen, pr->pHead, rlen);
			tot_rlen += rlen;
			pr->read += rlen;
		}
	}
	else
	{
		rlen = pr->write - pr->read;
		if (len < rlen)
			rlen = len;
		memcpy(data, pr->pHead + pr->read, rlen);
		tot_rlen = rlen;
		pr->read += rlen;
	}
	return tot_rlen;
}

int RingbufIsEmpty(Ringbuf_t *pr)
{
	int ret;

	if (pr->write == pr->read)
		ret = ringbufTRUE;
	else
		ret = ringbufFALSE;

	return ret;
}

int RingbufIsFull(Ringbuf_t *pr)
{
	int ret;

	if (pr->read <= pr->write)
	{
		if (pr->read != 0 || pr->write != pr->size)
			ret = ringbufFALSE;
		else
			ret = ringbufTRUE;
	}
	else
	{
		if (pr->write + 1 == pr->read)
			ret = ringbufTRUE;
		else
			ret = ringbufFALSE;
	}
	return ret;
}

RingbufSize_t RingbufGetBytesNum(Ringbuf_t *pr)
{
	RingbufSize_t bytes;

	if (pr->read <= pr->write)
	{
		bytes = pr->write - pr->read;
	}
	else
	{
		bytes = pr->size + 1 - pr->read;
		bytes += pr->write;
	}
	return bytes;
}

RingbufSize_t RingbufGetSpacesNum(Ringbuf_t *pr)
{
	RingbufSize_t spaces;

	if (pr->write < pr->read)
	{
		spaces = pr->read - pr->write - 1;
	}
	else
	{
		spaces = pr->size + 1 - pr->write;
		spaces += pr->read;
		spaces -= 1;
	}
	return spaces;
}
