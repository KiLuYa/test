#include "avltree.h"
#include <stdlib.h>  //����malloc��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *avltree_malloc(BaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= BaseType_t

	return p;
}

static void avltree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void avltree_memcpy(unsigned char *d, unsigned char *s, BaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

static BaseType_t avltree_memcmp(unsigned char *a1, unsigned char *a2, BaseType_t size)
{
	int ret = 0;

	while (size--)
	{
		if (*a1 == *a2)
		{
			a1++;
			a2++;
			continue;
		}
		if (*a1 > *a2)
		{
			ret = 1;
			break;
		}
		else
		{
			ret = -1;
			break;
		}
	}
	return ret;
}


typedef BaseType_t Stack_t;
typedef Stack_t *StackHandle_t;

static StackHandle_t StackCreate(BaseType_t n)
{
	BaseType_t *ps;

	ps = (BaseType_t *)avltree_malloc(sizeof(BaseType_t) + n * sizeof(void *));
	if (ps != NULL)
		*ps = -1;
	
	return ps;
}

static void StackDelete(StackHandle_t s)
{
	avltree_free((void *)s);
}

static void StackPush(StackHandle_t s, void *pn)
{
	BaseType_t *ps = s;
	void **ptr;

	ptr = (void **)(ps+1);
	(*ps)++;
	ptr[*ps] = pn;
}

static void *StackPop(StackHandle_t s)
{
	BaseType_t *ps = s;
	void **ptr;
	void *pn;

	ptr = (void **)(ps+1);
	pn = ptr[*ps];
	(*ps)--;

	return pn;
}

static void *StackGetTop(StackHandle_t s)
{
	BaseType_t *ps = s;
	void **ptr;
	void *pn;

	ptr = (void **)((unsigned char *)ps + sizeof(BaseType_t));
	pn = ptr[*ps];

	return pn;
}

static BaseType_t StackIsEmpty(StackHandle_t s)
{
	BaseType_t *ps = s;
	BaseType_t res;

	if (*ps == -1)
		res = 1;
	else
		res = 0;

	return res;
}

static BaseType_t StackGetTopIdx(StackHandle_t s)
{
	BaseType_t *ps = s;

	return *ps;
}


struct pos {
	void *p;
	BaseType_t spaces;
};


/**
 */
static AVLTreeNode_t *create_node(AVLTreeHandle_t avl, void *data)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn;

	pn = avltree_malloc(sizeof(AVLTreeNode_t) + pt->nodeSize);
	if (pn != NULL)
	{
		if(data != NULL)
			avltree_memcpy((unsigned char *)pn + sizeof(AVLTreeNode_t), data, pt->nodeSize);
		pn->parent = NULL;
		pn->left = NULL;
		pn->right = NULL;
		pn->height = 1;
	}

	return pn;
}

/**
 * In avl, copy pn2's content to pn1.
 */
static void copy_content(AVLTreeHandle_t avl, AVLTreeNode_t *pn1, AVLTreeNode_t *pn2)
{
	AVLTree_t *pt = avl;
	BaseType_t size = pt->nodeSize;

	avltree_memcpy((unsigned char *)pn1 + sizeof(AVLTreeNode_t), (unsigned char *)pn2 + sizeof(AVLTreeNode_t), size);
}

/**
 * Update pn->height. pn should not be NULL.
 */
static void update_height(AVLTreeNode_t *pn)
{
	BaseType_t hl, hr;

	if (pn->left == NULL) hl = 0;
	else hl = pn->left->height;

	if (pn->right == NULL) hr = 0;
	else hr = pn->right->height;

	pn->height = (hl > hr ? hl : hr) + 1;
}

/**
 * return pn's height.
 */
static BaseType_t get_height(AVLTreeNode_t *pn)
{
	BaseType_t hig;

	if (pn != NULL)
		hig = pn->height;
	else
		hig = 0;

	return hig;
}

/**
 * Rotate tree left.
 * Helper function for avltree_fixup( ).
 * x and x->right cannot be NULL.
 */
static void rotate_left(AVLTreeHandle_t avl, AVLTreeNode_t *x)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *y = x->right;

	x->right = y->left;
	if (y->left != NULL)
		y->left->parent = x;

	if (x->parent == NULL)
		pt->root = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;

	y->parent = x->parent;
	y->left = x;
	x->parent = y;

	update_height(x);  //the sequence cannot change
	update_height(y);
}

/**
 * Rotate tree right.
 * Helper function for avltree_fixup( ).
 * x and x->left cannot be NULL.
 */
static void rotate_right(AVLTreeHandle_t avl, AVLTreeNode_t *x)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *y = x->left;

	x->left = y->right;
	if (y->right != NULL)
		y->right->parent = x;

	if (x->parent == NULL)
		pt->root = y;
	else if (x->parent->left == x)
		x->parent->left = y;
	else
		x->parent->right = y;

	y->parent = x->parent;
	y->right = x;
	x->parent = y;

	update_height(x);  //the sequence cannot change
	update_height(y);
}

/**
 * Transplant t2 to t1 in AVLTree.
 * t1 cannot be NULL��t2 can be NULL.
 */
static void transplant(AVLTreeHandle_t avl, AVLTreeNode_t *t1, AVLTreeNode_t *t2)
{
	AVLTree_t *pt = avl;

	if (t1->parent == NULL)
	{
		pt->root = t2;
		if (t2 != NULL)
			t2->parent = NULL;
	}
	else
	{
		if (t1->parent->left == t1)
			t1->parent->left = t2;
		else
			t1->parent->right = t2;
		if (t2 != NULL)
			t2->parent = t1->parent;
	}
}

/**
 * Fixup the avltree to stay balance after insert a node.
 */
static void avltree_fixup_after_insert(AVLTreeHandle_t avl, AVLTreeNode_t *z)
{
	BaseType_t bf;  //balance factor

	while (z != NULL)
	{
		update_height(z);
		bf = get_height(z->left) - get_height(z->right);

		if (bf == 0)
			break;
		else if (bf == 2)
		{
			if (get_height(z->left->left) < get_height(z->left->right))
			{
				rotate_left(avl, z->left);
				update_height(z->left->left);
			}
			rotate_right(avl, z);
			update_height(z);
		}
		else if (bf == -2)
		{
			if (get_height(z->right->left) > get_height(z->right->right))
			{
				rotate_right(avl, z->right);
				update_height(z->right->right);
			}
			rotate_left(avl, z);
			update_height(z);
		}

		z = z->parent;
	}
}

/**
 * Fixup the avltree to stay balance after remove a node.
 */
static void avltree_fixup_after_remove(AVLTreeHandle_t avl, AVLTreeNode_t *z)
{
	BaseType_t bf;  //balance factor

	while (z != NULL)
	{
		update_height(z);
		bf = get_height(z->left) - get_height(z->right);

		if (bf == 1 || bf == -1)
			break;
		else if (bf == 2)
		{
			rotate_right(avl, z);
			update_height(z);
		}
		else if (bf == -2)
		{
			rotate_left(avl, z);
			update_height(z);
		}

		z = z->parent;
	}
}

/* ��̬�� �յ� */



/* API�� ��� */

AVLTreeHandle_t AVLTreeCreate(BaseType_t nodeSize, BaseType_t nodesNumLimit, AVLTreeNodeCompareFunc_t compareFunc, AVLTreeNodeVisitFunc_t visitFunc)
{
	AVLTree_t *pt;

	if (nodeSize == 0)
		return NULL;

	pt = avltree_malloc(sizeof(AVLTree_t));

	if (pt != NULL)
	{
		pt->root = NULL;
		pt->nodeSize = nodeSize;
		pt->nodesNum = 0;
		pt->nodesNumLimit = nodesNumLimit;
		pt->height = 0;
		pt->compareFunc = compareFunc;
		pt->visitFunc = visitFunc;
	}

	return pt;
}

BaseType_t AVLTreeDelete(AVLTreeHandle_t avl)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn, *visited;
	StackHandle_t s;

	if (pt == NULL)
		return 0;

	s = StackCreate(pt->height + 1);
	if (s == NULL)
		return 0;

	pn = pt->root;
	visited = NULL;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->left;
		}
		else
		{
			pn = StackGetTop(s);
			if (pn->right == NULL || pn->right == visited)
			{
				visited = pn;
				avltree_free(pn);

				(void)StackPop(s);
				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}
	avltree_free(pt);
	StackDelete(s);

	return 1;
}

BaseType_t AVLTreeInsert(AVLTreeHandle_t avl, void *data)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t **pp, *prev, *pn, *p;
	BaseType_t res;

	if (pt == NULL)
		return 0;

	if (pt->nodesNumLimit != 0 && pt->nodesNum >= pt->nodesNumLimit)
		return 0;

	p = create_node(avl, data);
	if (p == NULL)
		return 0;
	
	pp = &(pt->root);
	prev = NULL;
	pn = pt->root;

	while (pn != NULL)
	{
		res = pt->compareFunc((unsigned char *)pn + sizeof(AVLTreeNode_t), data);
		if (res > 0)
		{
			pp = &(pn->left);
			prev = pn;
			pn = pn->left;
		}
		else
		{
			pp = &(pn->right);
			prev = pn;
			pn = pn->right;
		}
	}
	
	p->parent = prev;
	*pp = p;

	avltree_fixup_after_insert(avl, p->parent);

	pt->height = pt->root->height;
	pt->nodesNum++;

	return 1;
}

BaseType_t AVLTreeRemove(AVLTreeHandle_t avl, void *data)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn, *r, *s;
	BaseType_t res, ret;

	if (pt == NULL)
		return 0;

	pn = pt->root;
	ret = 0;
	r = NULL;

	while (pn != NULL)
	{
		res = pt->compareFunc((unsigned char *)pn + sizeof(AVLTreeNode_t), data);
		if (res == 0)
		{
			if (pn->left == NULL)
			{
				r = pn->parent;
				transplant(avl, pn, pn->right);
				avltree_free(pn);
			}
			else
			{
				s = pn->left;
				while (s->right != NULL)
					s = s->right;
				r = s->parent;
				transplant(avl, s, s->left);
				copy_content(avl, pn, s);
				avltree_free(s);
			}
			ret = 1;
			break;
		}
		else if (res > 0)
			pn = pn->left;
		else
			pn = pn->right;
	}
	if (ret == 1)
	{
		avltree_fixup_after_remove(avl, r);

		if (pt->root == NULL)
			pt->height = 0;
		else
			pt->height = pt->root->height;
		pt->nodesNum--;
	}

	return ret;
}

void *AVLTreeSearch(AVLTreeHandle_t avl, void *data)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn;
	BaseType_t res;
	void *ret;

	if (pt == NULL)
		return NULL;

	pn = pt->root;
	ret = NULL;

	while (pn != NULL)
	{
		res = pt->compareFunc((unsigned char *)pn + sizeof(AVLTreeNode_t), data);
		if (res == 0)
		{
			ret = (unsigned char *)pn + sizeof(AVLTreeNode_t);
			break;
		}
		else if (res > 0)
			pn = pn->left;
		else
			pn = pn->right;
	}

	return ret;
}

AVLTreeHandle_t AVLTreeCopy(AVLTreeHandle_t avl)
{
	AVLTree_t *pst = avl;
	AVLTree_t *pdt;
	StackHandle_t s;
	AVLTreeNode_t *pn, *pn1, **prev, *parent;
	BaseType_t res;

	if (pst == NULL)
		return NULL;

	pdt = avltree_malloc(sizeof(AVLTree_t));
	if (pdt == NULL)
		return NULL;

	s = StackCreate(2*pst->height + 1);
	if (s == NULL)
	{
		avltree_free(pdt);
		return NULL;
	}

	pdt->root = NULL;
	pdt->nodeSize = pst->nodeSize;
	pdt->nodesNum = pst->nodesNum;
	pdt->nodesNumLimit = pst->nodesNumLimit;
	pdt->height = pst->height;
	pdt->compareFunc = pst->compareFunc;
	pdt->visitFunc = pst->visitFunc;

	pn = pst->root;
	prev = &(pdt->root);
	parent = NULL;
	res = 1;
	
	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			pn1 = create_node(avl, (unsigned char *)pn+sizeof(AVLTreeNode_t));
			if (pn1 == NULL)
			{
				res = 0;
				break;
			}
			*prev = pn1;
			pn1->parent = parent;
			pn1->height = pn->height;

			prev = &(pn1->left);
			parent = pn1;
			StackPush(s, pn);
			StackPush(s, pn1);
			pn = pn->left;
		}
		else
		{
			*prev = NULL;
			pn1 = StackPop(s);
			pn = StackPop(s);
			prev = &(pn1->right);
			parent = pn1;
			pn = pn->right;
		}
	}
	if (res == 1)
		*prev = NULL;
	else
	{
		res = AVLTreeDelete(pdt);
		if (res == 1)
			pdt = NULL;
		else
		{
			printf("warning: memory leak !!!\n");
			pdt = NULL;
			//while(1);
		}
	}

	StackDelete(s);

	return pdt;
}

BaseType_t AVLTreeInOrder(AVLTreeHandle_t avl, void *arg)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn;
	StackHandle_t s;

	if (pt == NULL)
		return 0;

	s = StackCreate(pt->height + 1);
	if (s == NULL)
		return 0;

	pn = pt->root;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->left;
		}
		else
		{
			pn = StackPop(s);
			pt->visitFunc((unsigned char *)pn+sizeof(AVLTreeNode_t), arg);
			pn = pn->right;
		}
	}

	StackDelete(s);

	return 1;
}

BaseType_t AVLTreeReInOrder(AVLTreeHandle_t avl, void *arg)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn;
	StackHandle_t s;

	if (pt == NULL)
		return 0;

	s = StackCreate(pt->height + 1);
	if (s == NULL)
		return 0;

	pn = pt->root;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->right;
		}
		else
		{
			pn = StackPop(s);
			pt->visitFunc((unsigned char *)pn + sizeof(AVLTreeNode_t), arg);
			pn = pn->left;
		}
	}

	StackDelete(s);

	return 1;
}

BaseType_t AVLTreeGetNodesNum(AVLTreeHandle_t avl)
{
	AVLTree_t *pt = avl;
	BaseType_t ret;

	if (pt == NULL)
		ret = -1;
	else
		ret = pt->nodesNum;

	return ret;
}

BaseType_t AVLTreeGetHeight(AVLTreeHandle_t avl)
{
	AVLTree_t *pt = avl;
	BaseType_t ret;

	if (pt == NULL)
		ret = -1;
	else
		ret = pt->height;

	return ret;
}

BaseType_t AVLTreeGetWidth(AVLTreeHandle_t avl)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn, *visited;
	StackHandle_t s;
	BaseType_t wid, *ptr;
	BaseType_t i;

	if (pt == NULL)
		return -1;

	if (pt->height == 0)
		return 0;

	s = StackCreate(pt->height + 1);
	if (s == NULL)
		return -1;

	ptr = avltree_malloc((pt->height) * sizeof(BaseType_t));
	if (ptr == NULL)
	{
		StackDelete(s);
		return -1;
	}
	for (i = 0; i < pt->height; i++)
		ptr[i] = 0;

	pn = pt->root;
	visited = NULL;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			pn = pn->left;
		}
		else
		{
			pn = StackGetTop(s);
			if (pn->right == NULL || pn->right == visited)
			{
				ptr[StackGetTopIdx(s)]++;
				visited = pn;

				(void)StackPop(s);
				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}
	wid = 0;
	for (i = 0; i < pt->height; i++)
	{
		if (ptr[i] > wid)
			wid = ptr[i];
	}

	StackDelete(s);
	avltree_free(ptr);

	return wid;
}

void AVLTreeSetNodeCompareFunc(AVLTreeHandle_t avl, AVLTreeNodeCompareFunc_t compareFunc)
{
	AVLTree_t *pt = avl;

	if (pt != NULL)
		pt->compareFunc = compareFunc;
}

void AVLTreeSetNodeVisitFunc(AVLTreeHandle_t avl, AVLTreeNodeVisitFunc_t visitFunc)
{
	AVLTree_t *pt = avl;

	if (pt != NULL)
		pt->visitFunc = visitFunc;
}

BaseType_t AVLTreePrint(AVLTreeHandle_t avl, BaseType_t dir)
{
	AVLTree_t *pt = avl;
	AVLTreeNode_t *pn;
	StackHandle_t s;
	struct pos *pos;
	BaseType_t i, num;
	BaseType_t j, max_line, k, m;

	if (pt == NULL)
		return 0;
	
	s = StackCreate(2*(pt->height) + 1);
	if (s == NULL)
		return 0;

	pos = avltree_malloc(pt->nodesNum * sizeof(struct pos));
	if (pos == NULL)
	{
		StackDelete(s);
		return 0;
	}

	pn = pt->root;
	num = 0;
	k = 0;

	while (!StackIsEmpty(s) || pn != NULL)
	{
		if (pn != NULL)
		{
			StackPush(s, pn);
			StackPush(s, (void *)k);
			pn = pn->right;
			k++;
		}
		else
		{
			k = (BaseType_t)StackPop(s);
			pn = StackPop(s);

			pos[num].p = (unsigned char *)pn + sizeof(AVLTreeNode_t);
			pos[num].spaces = k;
			num++;
			pn = pn->left;
			k++;
		}
	}

	if (dir == 0)
	{
		for (i = 0; i < num; i++)
		{
			for (j = 0; j < pos[i].spaces; j++)
				printf(" ");
			printf("%d\n", *(int *)(pos[i].p));
		}
	}
	else
	{
		max_line = 0;
		for (i = 0; i < num; i++)
			if (pos[i].spaces > max_line)
				max_line = pos[i].spaces;
		for (i = 0; i <= max_line; i++)
		{
			k = num;
			for (j = num - 1; j >= 0; j--)
			{
				if (pos[j].spaces == i)
				{
					for (m = 0; m < k - j - 1; m++)
						printf(" ");
					printf("%d", *(int *)(pos[j].p));
					k = j;
				}
			}
			printf("\n");
		}
	}

	StackDelete(s);
	avltree_free(pos);

	return 1;
}

/* API�� �յ� */
