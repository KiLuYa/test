#include "bitree.h"
#include <stdlib.h>  //����mallco��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *bitree_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= UBaseType_t

	return p;
}

static void bitree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void bitree_memcpy(unsigned char *d, unsigned char *s, UBaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

static int bitree_memcmp(unsigned char *a1, unsigned char *a2, UBaseType_t size)
{
	int ret = 0;

	while (size--)
	{
		if (*a1 == *a2)
		{
			a1++;
			a2++;
			continue;
		}
		if (*a1 > *a2)
		{
			ret = 1;
			break;
		}
		else
		{
			ret = -1;
			break;
		}
	}
	return ret;
}


/* by post order traversal */
static void deleteBitree(BitreeNode_t *pn)
{
	if (pn != NULL)
	{
		deleteBitree(pn->left);
		deleteBitree(pn->right);
		bitree_free(pn);
	}
}

/* by pre order traversal */
static BitreeNode_t *copyBitree(BitreeNode_t *pn, UBaseType_t size, BaseType_t *err)
{
	BitreeNode_t *pn1 = NULL;

	if (*err == 0)
	{
		if (pn != NULL)
		{
			pn1 = bitree_malloc(sizeof(BitreeNode_t) + size);
			if (pn1 != NULL)
			{
				pn1->left = NULL;
				pn1->right = NULL;
				bitree_memcpy((unsigned char*)pn1 + sizeof(BitreeNode_t), (unsigned char *)pn + sizeof(BitreeNode_t), size);
				pn1->left = copyBitree(pn->left, size, err);
				pn1->right = copyBitree(pn->right, size, err);
			}
			else
				*err = 1;
		}
		else
			pn1 = NULL;
	}

	return pn1;
}

static void preOrder(BitreeNode_t *pn, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	if (pn != NULL)
	{
		nodeVisitFunc(pn, arg);
		preOrder(pn->left, nodeVisitFunc, arg);
		preOrder(pn->right, nodeVisitFunc, arg);
	}
}

static void inOrder(BitreeNode_t *pn, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	if (pn != NULL)
	{
		inOrder(pn->left, nodeVisitFunc, arg);
		nodeVisitFunc(pn, arg);
		inOrder(pn->right, nodeVisitFunc, arg);
	}
}

static void postOrder(BitreeNode_t *pn, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	if (pn != NULL)
	{
		postOrder(pn->left, nodeVisitFunc, arg);
		postOrder(pn->right, nodeVisitFunc, arg);
		nodeVisitFunc(pn, arg);
	}
}

static UBaseType_t cntTerminalNodes(BitreeNode_t *pn)
{
	UBaseType_t cnt;

	if (pn == NULL)
		cnt = 0;
	else if ((pn->left == NULL) && (pn->right == NULL))
		cnt = 1;
	else
		cnt = cntTerminalNodes(pn->left) + cntTerminalNodes(pn->right);

	return cnt;
}

/* by post order traversal */
static UBaseType_t cntBitreeHeight(BitreeNode_t *pn)
{
	UBaseType_t hl, hr, hig;

	if (pn != NULL)
	{
		hl = cntBitreeHeight(pn->left);
		hr = cntBitreeHeight(pn->right);
		hig = hl > hr ? hl : hr;
		return hig + 1;
	}
	else
		hig = 0;

	return hig;
}

/* by inverse-inorder traversal */
static void printBitree_0(BitreeNode_t *pn, UBaseType_t spaces)
{
	UBaseType_t i;

	if (pn != NULL)
	{
		printBitree_0(pn->right, spaces + 1);
		for (i = 0; i < spaces; i++)
			printf(" ");
		printf("%c\n", *((char *)pn + sizeof(BitreeNode_t)));
		printBitree_0(pn->left, spaces + 1);
	}
}

static void printBitree_1(BitreeNode_t *pn, UBaseType_t spaces)
{

}

/* by pre/post order traversal */
static void switchBitreeChildren(BitreeNode_t *pn)
{
	BitreeNode_t *tmp;

	if (pn != NULL)
	{
		switchBitreeChildren(pn->left);
		switchBitreeChildren(pn->right);
		tmp = pn->left;
		pn->left = pn->right;
		pn->right = tmp;
	}
}

/* by pre order traversal */
static BaseType_t isSimilar(BitreeNode_t *pn1, BitreeNode_t *pn2)
{
	BaseType_t like1, like2, ret;

	if (pn1 == NULL && pn2 == NULL)
		ret = 1;
	else if (pn1 == NULL || pn2 == NULL)
		ret = 0;
	else {
		like1 = isSimilar(pn1->left, pn2->left);
		like2 = isSimilar(pn1->right, pn2->right);
		ret = like1 && like2;
	}

	return ret;
}

/* optimized version of function isSimilar */
static BaseType_t isSimilar_optimized(BitreeNode_t *pn1, BitreeNode_t *pn2)
{
	BaseType_t like;

	if (pn1 == NULL && pn2 == NULL)
		return 1;
	else if (pn1 == NULL || pn2 == NULL)
		return 0;
	else {
		like = isSimilar_optimized(pn1->left, pn2->left);
		if (like == 0) return 0;
		like = isSimilar_optimized(pn1->right, pn2->right);
		return like;
	}
}

/* by pre order traversal */
static BaseType_t isSame(BitreeNode_t *pn1, BitreeNode_t *pn2, UBaseType_t size)
{
	BaseType_t ret;

	if (pn1 == NULL && pn2 == NULL)
		return 1;
	else if (pn1 == NULL || pn2 == NULL)
		return 0;
	else
	{
		if (bitree_memcmp((char *)pn1 + sizeof(BitreeNode_t), (char *)pn2 + sizeof(BitreeNode_t), size) != 0)
			return 0;
		ret = isSame(pn1->left, pn2->left, size);
		if (ret == 0)
			return 0;
		ret = isSame(pn1->right, pn2->right, size);
		return ret;
	}
}

/* ��̬�� �յ� */



/* API�� ��� */

BitreeHandle_t BitreeCreate(UBaseType_t nodeSize, UBaseType_t nodesNumLimit)
{
	Bitree_t *pt;

	if (nodeSize == 0)
		return NULL;

	pt = (Bitree_t *)bitree_malloc(sizeof(Bitree_t));

	if (pt != NULL)
	{
		pt->root = NULL;
		pt->nodeSize = nodeSize;
		pt->nodesNum = 0;
		pt->nodesNumLimit = nodesNumLimit;
	}

	return pt;
}

void BitreeDelete(BitreeHandle_t bt)
{
	Bitree_t *pt = bt;

	if (pt != NULL)
	{
		deleteBitree(pt->root);
		bitree_free(pt);
	}
}

BitreeHandle_t BitreeCopy(BitreeHandle_t sbt)
{
	Bitree_t *pst = sbt;
	Bitree_t *pdt;
	BaseType_t err;

	if (pst == NULL)
		return NULL;

	pdt = BitreeCreate(pst->nodeSize, pst->nodesNumLimit);

	if (pdt != NULL)
	{
		pdt->nodesNum = pst->nodesNum;
		err = 0;
		pdt->root = copyBitree(pst->root, pst->nodeSize, &err);
		if (err == 1)
		{
			BitreeDelete(pdt);
			pdt = NULL;
		}
	}
	return pdt;
}

void BitreePreOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt = bt;

	if(pt != NULL)
		preOrder(pt->root, nodeVisitFunc, arg);
}

void BitreeInOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt = bt;

	if (pt != NULL)
		inOrder(pt->root, nodeVisitFunc, arg);
}

void BitreePostOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt = bt;

	if (pt != NULL)
		postOrder(pt->root, nodeVisitFunc, arg);
}

void BitreeLayerOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{

}

UBaseType_t BitreeGetNodesNum(BitreeHandle_t bt)
{
	Bitree_t *pt = bt;

	if (pt == NULL)
		return 0;

	return pt->nodesNum;
}

UBaseType_t BitreeGetTerminalNodesNum(BitreeHandle_t bt)
{
	Bitree_t *pt = bt;
	UBaseType_t terminalNodesNum = 0;

	if (pt != NULL)
		terminalNodesNum = cntTerminalNodes(pt->root);

	return terminalNodesNum;
}

UBaseType_t BitreeGetHeight(BitreeHandle_t bt)
{
	Bitree_t *pt = bt;
	UBaseType_t hig = 0;

	if (pt != NULL)
		hig = cntBitreeHeight(pt->root);

	return hig;
}

UBaseType_t BitreeGetWidth(BitreeHandle_t bt)
{
	return 0;
}

void BitreeVisitPath(BitreeHandle_t bt, BitreeNode_t *pNode, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{

}

void BitreePrint(BitreeHandle_t bt, UBaseType_t dir)
{
	Bitree_t *pt = bt;

	if (pt == NULL)
		return;

	if (dir == 0)
		printBitree_0(pt->root, 0);
	else
		printBitree_1(pt->root, 0);
}

void BitreeSwitchChildren(BitreeHandle_t bt)
{
	Bitree_t *pt = bt;

	if (pt != NULL)
		switchBitreeChildren(pt->root);
}

BaseType_t BitreeIsSimilar(BitreeHandle_t bt1, BitreeHandle_t bt2)
{
	Bitree_t *pt1 = bt1;
	Bitree_t *pt2 = bt2;
	BaseType_t ret;

	if (pt1 == NULL || pt2 == NULL)
		return 0;

	if (pt1->nodeSize != pt2->nodeSize || pt1->nodesNum != pt2->nodesNum)
		return 0;

	ret = isSimilar(pt1->root, pt2->root);
	//ret = isSimilar_optimized(pt1->root, pt2->root);

	return ret;
}

BaseType_t BitreeIsSame(BitreeHandle_t bt1, BitreeHandle_t bt2)
{
	Bitree_t *pt1 = bt1;
	Bitree_t *pt2 = bt2;
	BaseType_t ret;

	if (pt1 == NULL || pt2 == NULL)
		return 0;

	if (pt1->nodeSize != pt2->nodeSize || pt1->nodesNum != pt2->nodesNum)
		return 0;

	ret = isSame(pt1->root, pt2->root, pt1->nodeSize);

	return ret;
}

/* API�� �յ� */
