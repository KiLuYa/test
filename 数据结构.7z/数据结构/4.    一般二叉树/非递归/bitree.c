#include "bitree.h"
#include <stdlib.h>  //����mallco��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *bitree_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= UBaseType_t

	return p;
}

static void bitree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

#define  BITREE_MAX_HEIGHT  50
#define  BITREE_MAX_NODES_FOR_PRINT  200
#define  BITREE_MAX_WIDTH   100


static void bitree_memcpy(unsigned char *d, unsigned char *s, UBaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

static BaseType_t bitree_memcmp(unsigned char *a1, unsigned char *a2, UBaseType_t size)
{
	int ret = 0;

	while (size--)
	{
		if (*a1 == *a2)
		{
			a1++;
			a2++;
			continue;
		}
		if (*a1 > *a2)
		{
			ret = 1;
			break;
		}
		else
		{
			ret = -1;
			break;
		}
	}
	return ret;
}


struct stack {
	BaseType_t top;
	BitreeNode_t *ptr[BITREE_MAX_HEIGHT];
};
typedef struct stack Stack_t;

static void StackInit(Stack_t *ps)
{
	ps->top = -1;
}

static BaseType_t StackPush(Stack_t *ps, BitreeNode_t *pn)
{
	BaseType_t res;

	if (ps->top == BITREE_MAX_HEIGHT-1)
		res = 0;
	else
	{
		ps->top++;
		(ps->ptr)[ps->top] = pn;
		res = 1;
	}
	return res;
}

static BaseType_t StackPop(Stack_t *ps, BitreeNode_t **ppn)
{
	BaseType_t res;

	if (ps->top == -1)
		res = 0;
	else
	{
		*ppn = (ps->ptr)[ps->top];
		ps->top--;
		res = 1;
	}
	return res;
}

static BaseType_t StackGetTop(Stack_t *ps, BitreeNode_t **ppn)
{
	BaseType_t res;

	if (ps->top == -1)
		res = 0;
	else
	{
		*ppn = (ps->ptr)[ps->top];
		res = 1;
	}
	return res;
}

static BaseType_t StackIsEmpty(Stack_t *ps)
{
	BaseType_t res;

	if (ps->top == -1)
		res = 1;
	else
		res = 0;
	return res;
}

static BaseType_t StackGetTopIdx(Stack_t *ps)
{
	return ps->top;
}


struct queue {
	UBaseType_t read;
	UBaseType_t write;
	UBaseType_t length;
	UBaseType_t messages;
	BitreeNode_t *ptr[BITREE_MAX_WIDTH * 3 / 2];
};
typedef struct queue Queue_t;

static void QueueInit(Queue_t *pq)
{
	pq->read = 0;
	pq->write = 0;
	pq->length = BITREE_MAX_WIDTH * 3 / 2;
	pq->messages = 0;
}

static BaseType_t QueueSend(Queue_t *pq, BitreeNode_t *pn)
{
	BaseType_t res;

	if (pq->messages >= pq->length)
		res = 0;
	else
	{
		pq->ptr[pq->write] = pn;
		pq->write++;
		if (pq->write == pq->length)
			pq->write = 0;
		pq->messages++;
		res = 1;
	}
	return res;
}

static BaseType_t QueueReceive(Queue_t *pq, BitreeNode_t **ppn)
{
	BaseType_t res;

	if (pq->messages == 0)
		res = 0;
	else
	{
		*ppn = pq->ptr[pq->read];
		pq->read++;
		if (pq->read == pq->length)
			pq->read = 0;
		pq->messages--;
		res = 1;
	}
	return res;
}

static BaseType_t QueueIsEmpty(Queue_t *pq)
{
	BaseType_t res;
	
	if (pq->messages == 0)
		res = 1;
	else
		res = 0;

	return res;
}


struct pos {
	BitreeNode_t *pn;
	BaseType_t spaces;
};

/* ��̬�� �յ� */



/* API�� ���*/

BitreeHandle_t BitreeCreate(UBaseType_t nodeSize, UBaseType_t nodesNumLimit)
{
	Bitree_t *pt;

	if (nodeSize == 0)
		return NULL;

	pt = (Bitree_t *)bitree_malloc((UBaseType_t)sizeof(Bitree_t));

	if (pt != NULL)
	{
		pt->root = NULL;
		pt->nodeSize = nodeSize;
		pt->nodesNum = 0;
		pt->nodesNumLimit = nodesNumLimit;
	}

	return pt;
}

/* by post order traversal */
BaseType_t BitreeDelete(BitreeHandle_t bt)
{
	Bitree_t *pt;
	BitreeNode_t *pn, *visited;
	Stack_t s;
	BaseType_t res;

	if (bt == NULL)
		return 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	visited = NULL;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackGetTop(&s, &pn);
			if (res == 0)
				break;
			if (pn->right == NULL || pn->right == visited)
			{
				visited = pn;
				bitree_free(pn);

				res = StackPop(&s, &pn);
				if (res == 0)
					break;

				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}
	if (res == 1)
		bitree_free(pt);

	return res;
}

/* by pre order traversal */
BitreeHandle_t BitreeCopy(BitreeHandle_t sbt)
{
	Bitree_t *pt, *pt1;
	BitreeNode_t *pn, *pn1, **pp;
	Stack_t s;
	BaseType_t res;

	if (sbt == NULL)
		return NULL;
	
	pt = sbt;
	pt1 = (Bitree_t *)bitree_malloc(sizeof(Bitree_t));
	if (pt1 == NULL)
		return NULL;
	pt1->root = NULL;
	pt1->nodeSize = pt->nodeSize;
	pt1->nodesNum = pt->nodesNum;
	pt1->nodesNumLimit = pt->nodesNumLimit;
	pp = &(pt1->root);

	StackInit(&s);
	pn = pt->root;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			pn1 = (BitreeNode_t *)bitree_malloc(sizeof(BitreeNode_t) + pt->nodeSize);
			if (pn1 == NULL)
			{
				res = 0;
				break;
			}
			pn1->left = NULL;
			pn1->right = NULL;
			bitree_memcpy((char *)pn1 + sizeof(BitreeNode_t), (char *)pn + sizeof(BitreeNode_t), pt->nodeSize);
			*pp = pn1;
			pp = &(pn1->left);
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			res = StackPush(&s, pn1);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			*pp = NULL;
			res = StackPop(&s, &pn1);
			if (res == 0)
				break;
			res = StackPop(&s, &pn);
			if (res == 0)
				break;
			pp = &(pn1->right);
			pn = pn->right;
		}
	}
	if (res == 1)
		*pp = NULL;
	else
	{
		BitreeDelete(pt1);
		pt1 = NULL;
	}

	return pt1;
}

/* preorder traversal */
BaseType_t BitreePreOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt;
	BitreeNode_t *pn;
	Stack_t s;
	BaseType_t res;

	if (bt == NULL)
		return 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			nodeVisitFunc(pn, arg);
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackPop(&s, &pn);
			if (res == 0)
				break;
			pn = pn->right;
		}
	}

	return res;
}

/* inorder traversal */
BaseType_t BitreeInOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt;
	BitreeNode_t *pn;
	Stack_t s;
	BaseType_t res;

	if (bt == NULL)
		return 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackPop(&s, &pn);
			if (res == 0)
				break;
			nodeVisitFunc(pn, arg);
			pn = pn->right;
		}
	}

	return res;
}

/* postorder traversal
 * It's a little different from preorder & inorder, because when we
 * get back to a ptr, we need to judge whether we have already traversed
 * both two child trees.
 */
BaseType_t BitreePostOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt;
	BitreeNode_t *pn, *visited;
	Stack_t s;
	BaseType_t res;

	if (bt == NULL)
		return 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	visited = NULL;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackGetTop(&s, &pn);
			if (res == 0)
				break;
			if (pn->right == NULL || pn->right == visited)
			{
				nodeVisitFunc(pn, arg);
				visited = pn;

				res = StackPop(&s, &pn);
				if (res == 0)
					break;

				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}

	return res;
}

/* traverse bitree in layer order */
BaseType_t BitreeLayerOrder(BitreeHandle_t bt, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt;
	BitreeNode_t *pn;
	Queue_t q;
	BaseType_t res;

	if (bt == NULL)
		return 0;

	QueueInit(&q);
	pt = bt;
	pn = pt->root;
	res = 1;
	QueueSend(&q, pn);

	while (!QueueIsEmpty(&q))
	{
		(void)QueueReceive(&q, &pn);
		nodeVisitFunc(pn, arg);
		if (pn->left != NULL)
		{
			res = QueueSend(&q, pn->left);
			if (res == 0)
				break;
		}
		if (pn->right != NULL)
		{
			res = QueueSend(&q, pn->right);
			if (res == 0)
				break;
		}
	}

	return res;
}

UBaseType_t BitreeGetNodesNum(BitreeHandle_t bt)
{
	Bitree_t *pt = bt;

	return pt->nodesNum;
}

/* by any order traversal */
BaseType_t BitreeGetTerminalNodesNum(BitreeHandle_t bt)
{
	Bitree_t *pt;
	BitreeNode_t *pn;
	Stack_t s;
	BaseType_t res;
	BaseType_t n;

	if (bt == NULL)
		return -1;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	res = 1;
	n = 0;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			if (pn->left == NULL && pn->right == NULL)
				n++;
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackPop(&s, &pn);
			if (res == 0)
				break;
			pn = pn->right;
		}
	}
	if (res == 0)
		n = -1;
	return n;
}

/* by post order traversal */
BaseType_t BitreeGetHeight(BitreeHandle_t bt)
{
	Bitree_t *pt;
	BitreeNode_t *pn, *visited;
	Stack_t s;
	BaseType_t res;
	BaseType_t hig, hig_max;

	if (bt == NULL)
		return -1;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	visited = NULL;
	res = 1;
	hig_max = 0;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackGetTop(&s, &pn);
			if (res == 0)
				break;
			if (pn->right == NULL || pn->right == visited)
			{
				hig = StackGetTopIdx(&s);
				if (hig > hig_max)
					hig_max = hig;
				visited = pn;

				res = StackPop(&s, &pn);
				if (res == 0)
					break;

				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}
	if (res == 0)
		hig_max = -1;

	return hig_max + 1;
}

/**
 * by post order traversal
 * another method: use LayerOrder, when we put a pNode into queue, we also put its layer value into the queue
 */
BaseType_t BitreeGetWidth(BitreeHandle_t bt)
{
	Bitree_t *pt;
	BitreeNode_t *pn, *visited;
	Stack_t s;
	BaseType_t res;
	BaseType_t num[BITREE_MAX_HEIGHT], max;
	BaseType_t hig, i;

	if (bt == NULL)
		return -1;

	hig = BitreeGetHeight(bt);
	if (hig == -1)
		return -1;
	else if (hig == 0)
		return 0;

	for (i = 0; i < hig; i++)
		num[i] = 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	visited = NULL;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackGetTop(&s, &pn);
			if (res == 0)
				break;
			if (pn->right == NULL || pn->right == visited)
			{
				i = StackGetTopIdx(&s);
				num[i]++;
				visited = pn;

				res = StackPop(&s, &pn);
				if (res == 0)
					break;

				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}

	if (res == 0)
		max = -1;
	else
	{
		max = 0;
		for (i = 0; i < hig; i++)
		{
			if (num[i] > max)
				max = num[i];
		}
	}

	return max;
}

/**
 * by post order traversal
 * this is hard to use recursion method
 */
BaseType_t BitreeVisitPath(BitreeHandle_t bt, BitreeNode_t *pNode, BitreeNodeVisitFunc_t nodeVisitFunc, void *arg)
{
	Bitree_t *pt;
	BitreeNode_t *pn, *visited;
	Stack_t s;
	BaseType_t res;
	BaseType_t i;

	if (bt == NULL)
		return 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	visited = NULL;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackGetTop(&s, &pn);
			if (res == 0)
				break;
			if (pn->right == NULL || pn->right == visited)
			{
				if (pn == pNode)
				{
					for (i = 0; i <= StackGetTopIdx(&s); i++)
						nodeVisitFunc(s.ptr[i], arg);
					break;
				}
				visited = pn;

				res = StackPop(&s, &pn);
				if (res == 0)
					break;

				pn = NULL;
			}
			else
				pn = pn->right;
		}
	}

	return res;
}

/* by inverse-inorder traversal */
BaseType_t BitreePrint(BitreeHandle_t bt, UBaseType_t dir)
{
	Bitree_t *pt;
	BitreeNode_t *pn;
	Stack_t s;
	BaseType_t res;
	struct pos pos[BITREE_MAX_NODES_FOR_PRINT];
	BaseType_t i, num;
	BaseType_t j, max_line, k, m;


	if (bt == NULL)
		return 0;

	if (BitreeGetNodesNum(bt) > BITREE_MAX_NODES_FOR_PRINT)
		return 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	res = 1;
	num = 0;
	k = 0;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			res = StackPush(&s, pn);
			if (res == 0)
				break;
			res = StackPush(&s, (BitreeNode_t *)k);
			if (res == 0)
				break;
			pn = pn->right;
			k++;
		}
		else
		{
			res = StackPop(&s, (BitreeNode_t **)&k);
			if (res == 0)
				break;
			res = StackPop(&s, &pn);
			if (res == 0)
				break;
			
			pos[num].pn = pn;
			pos[num].spaces = k;
			num++;

			pn = pn->left;
			k++;
		}
	}
	if (res == 0)
		return 0;

	if (dir == 0)
	{
		for (i = 0; i < num; i++)
		{
			for(j=0;j<pos[i].spaces;j++)
				printf(" ");
			printf("%c\n", *((char *)(pos[i].pn)+sizeof(BitreeNode_t)));
		}
	}
	else
	{
		max_line = 0;
		for (i = 0; i < num; i++)
			if (pos[i].spaces > max_line)
				max_line = pos[i].spaces;
		for (i = 0; i <= max_line; i++)
		{
			k = num;
			for (j = num - 1; j >= 0; j--)
			{
				if (pos[j].spaces == i)
				{
					for (m = 0; m < k - j - 1; m++)
						printf(" ");
					printf("%c", *((char *)(pos[j].pn) + sizeof(BitreeNode_t)));
					k = j;
				}
			}
			printf("\n");
		}
	}

	return 1;
}

/* by pre/post order traversal */
BaseType_t BitreeSwitchChildren(BitreeHandle_t bt)
{
	Bitree_t *pt;
	BitreeNode_t *pn, *tmp;
	Stack_t s;
	BaseType_t res;

	if (bt == NULL)
		return 0;

	StackInit(&s);

	pt = bt;
	pn = pt->root;
	res = 1;

	while (!StackIsEmpty(&s) || pn != NULL)
	{
		if (pn != NULL)
		{
			tmp = pn->left;
			pn->left = pn->right;
			pn->right = tmp;

			res = StackPush(&s, pn);
			if (res == 0)
				break;
			pn = pn->left;
		}
		else
		{
			res = StackPop(&s, &pn);
			if (res == 0)
				break;
			pn = pn->right;
		}
	}

	return res;
}

/* by any order traversal */
BaseType_t BitreeIsSimilar(BitreeHandle_t bt1, BitreeHandle_t bt2)
{
	Bitree_t *pt1, *pt2;
	BitreeNode_t *pn1, *pn2;
	Stack_t s;
	BaseType_t res;

	if (bt1 == NULL || bt2 == NULL)
		return -1;

	StackInit(&s);

	pt1 = bt1;
	pt2 = bt2;
	if (pt1->nodeSize != pt2->nodeSize || pt1->nodesNum != pt2->nodesNum)
		return 0;
	pn1 = pt1->root;
	pn2 = pt2->root;
	res = 1;

	while (!StackIsEmpty(&s) || pn1 != NULL)
	{
		if (pn1 != NULL)
		{
			if (pn2 == NULL)
			{
				res = 0;
				break;
			}
			res = StackPush(&s, pn1);
			if (res == 0)
			{
				res = -1;
				break;
			}
			res = StackPush(&s, pn2);
			if (res == 0)
			{
				res = -1;
				break;
			}
			pn1 = pn1->left;
			pn2 = pn2->left;
		}
		else
		{
			if (pn2 != NULL)
			{
				res = 0;
				break;
			}
			res = StackPop(&s, &pn2);
			if (res == 0)
			{
				res = -1;
				break;
			}
			res = StackPop(&s, &pn1);
			if (res == 0)
			{
				res = -1;
				break;
			}
			pn1 = pn1->right;
			pn2 = pn2->right;
		}
	}
	if (res == 1)
		if (pn2 != NULL)
			res = 0;

	return res;
}

/* by any order traversal */
BaseType_t BitreeIsSame(BitreeHandle_t bt1, BitreeHandle_t bt2)
{
	Bitree_t *pt1, *pt2;
	BitreeNode_t *pn1, *pn2;
	Stack_t s;
	BaseType_t res;

	if (bt1 == NULL || bt2 == NULL)
		return -1;

	StackInit(&s);

	pt1 = bt1;
	pt2 = bt2;
	if (pt1->nodeSize != pt2->nodeSize || pt1->nodesNum != pt2->nodesNum)
		return 0;
	pn1 = pt1->root;
	pn2 = pt2->root;
	res = 1;

	while (!StackIsEmpty(&s) || pn1 != NULL)
	{
		if (pn1 != NULL)
		{
			if (pn2 == NULL)
			{
				res = 0;
				break;
			}
			if (bitree_memcmp((unsigned char *)pn1 + sizeof(BitreeNode_t), (unsigned char *)pn2 + sizeof(BitreeNode_t), pt1->nodeSize) != 0)
			{
				res = 0;
				break;
			}
			res = StackPush(&s, pn1);
			if (res == 0)
			{
				res = -1;
				break;
			}
			res = StackPush(&s, pn2);
			if (res == 0)
			{
				res = -1;
				break;
			}
			pn1 = pn1->left;
			pn2 = pn2->left;
		}
		else
		{
			if (pn2 != NULL)
			{
				res = 0;
				break;
			}
			res = StackPop(&s, &pn2);
			if (res == 0)
			{
				res = -1;
				break;
			}
			res = StackPop(&s, &pn1);
			if (res == 0)
			{
				res = -1;
				break;
			}
			pn1 = pn1->right;
			pn2 = pn2->right;
		}
	}
	if (res == 1)
		if (pn2 != NULL)
			res = 0;

	return res;
}

/* API�� �յ�*/
