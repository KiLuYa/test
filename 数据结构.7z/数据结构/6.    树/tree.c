
typedef struct node {
	char c;
	struct node *fc;  //first child
	struct node *sibling;
} TNode ,*Tree;


/**
 * Get the depth of tree in postorder(inorder/preorder).
 * See tree as BiTree, inorder traversal of BiTree is the same as postorder of Tree.
 * 
 * @param t  Tree
 */
int TreeDepth(Tree t)
{
	TNode *p;
	//stack
	TNode* s[STACK_SIZE];
	int top = 0;
	int max = 0;
	
	p = t;
	while(p!=NULL || top!=0) {
		if(p != NULL){
			top++;  //push stack
			if(top >= STACK_SIZE) {printf("stack is full\n");while(1);}
			s[top] = p;
			
			p = p->fc;
		} else {
			p = s[top];  //pop stack
			top--;
			
			if(top > max) max = top;
			p = p->sibling;
		}
	}
	return max+1;
}

/**
 * Print tree in concave table.
 * In preorder(preorder).
 * 
 * @param t  Tree
 */
void PrintTree(Tree t)
{
	TNode *p;
	//stack
	TNode* s[STACK_SIZE];
	int top = 0;
	
	int i;
	
	p = t;
	while(p!=NULL || top!=0) {
		if(p != NULL){
			for(i=0 ; i<top ; i++)
				printf(" ");
			printf("%c\n", p->data);
			
			top++;  //push stack
			if(top >= STACK_SIZE) {printf("stack is full\n");while(1);}
			s[top] = p;
			
			p = p->fc;
		} else {
			p = s[top];  //pop stack
			top--;

			p = p->sibling;
		}
	}
}


