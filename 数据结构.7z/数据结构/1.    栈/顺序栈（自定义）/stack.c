#include "stack.h"


#define stackTRUE   1
#define stackFALSE  0


void StackInit(Stack_t *ps)
{
	ps->top = -1;
}

int StackPush(Stack_t *ps, StackElement_t x)
{
	int res = stackTRUE;

	if (ps->top == STACK_BUFFER_SIZE - 1)
	{
		res = stackFALSE;
	}
	else
	{
		ps->top++;
		ps->elem[ ps->top ] = x;
	}

	return res;
}

int StackPop(Stack_t *ps, StackElement_t *px)
{
	int res = stackTRUE;

	if (ps->top == -1)
	{
		res = stackFALSE;
	}
	else
	{
		*px = ps->elem[ ps->top ];
		ps->top--;
	}
	
	return res;
}

int StackGetTop(Stack_t *ps, StackElement_t *px)
{
	int res = stackTRUE;

	if (ps->top == -1)
	{
		res = stackFALSE;
	}
	else
	{
		*px = ps->elem[ ps->top ];
	}

	return res;
}

int StackIsEmpty(Stack_t *ps)
{
	int res;

	if (ps->top == -1)
		res = stackTRUE;
	else
		res = stackFALSE;

	return res;
}

int StackIsFull(Stack_t *ps)
{
	int res;

	if (ps->top == STACK_BUFFER_SIZE - 1)
		res = stackTRUE;
	else
		res = stackFALSE;

	return res;
}
