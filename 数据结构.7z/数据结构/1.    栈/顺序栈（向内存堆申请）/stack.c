#include "stack.h"
#include <stdlib.h>  //����C���malloc��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *stack_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ���Ҫ >= UBaseType_t

	return p;
}

static void stack_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void stack_memcpy(unsigned char *d, unsigned char *s, UBaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

/* ��̬�� �յ� */



/* API�� ��� */

StackHandle_t StackCreate(UBaseType_t nodeSize, UBaseType_t length)
{
	Stack_t *ps;
	UBaseType_t len;

	if (nodeSize == 0 || length == 0)
		return NULL;

	len = (UBaseType_t)sizeof(Stack_t) + nodeSize * length;
	ps = (Stack_t *)stack_malloc(len);

	if (ps != NULL)
	{
		ps->top = NULL;
		ps->nodeSize = nodeSize;
		ps->length = length;
		ps->head = (unsigned char *)ps + sizeof(Stack_t);
		ps->tail = ps->head + nodeSize * (length - 1);
	}

	return ps;
}

void StackDelete(StackHandle_t s)
{
	Stack_t *ps = s;

	if(ps != NULL)
		stack_free((void *)ps);
}

BaseType_t StackPush(StackHandle_t s, void *p)
{
	Stack_t *ps = s;
	BaseType_t res;

	if (ps == NULL)
		return 0;

	if (ps->top >= ps->tail)
	{
		res = 0;
	}
	else
	{
		if (ps->top == NULL)
			ps->top = ps->head;
		else
			ps->top += ps->nodeSize;

		stack_memcpy(ps->top, (unsigned char *)p, ps->nodeSize);

		res = 1;
	}

	return res;
}

BaseType_t StackPop(StackHandle_t s, void *p)
{
	Stack_t *ps = s;
	BaseType_t res;

	if (ps == NULL)
		return 0;

	if (ps->top == NULL)
	{
		res = 0;
	}
	else
	{
		stack_memcpy((unsigned char *)p, ps->top, ps->nodeSize);
		if (ps->top == ps->head)
			ps->top = NULL;
		else
			ps->top -= ps->nodeSize;

		res = 1;
	}
	
	return res;
}

BaseType_t StackGetTop(StackHandle_t s, void *p)
{
	Stack_t *ps = s;
	BaseType_t res;

	if (ps == NULL)
		return 0;

	if (ps->top == NULL)
	{
		res = 0;
	}
	else
	{
		stack_memcpy((unsigned char *)p, ps->top, ps->nodeSize);

		res = 1;
	}

	return res;
}

BaseType_t StackIsEmpty(StackHandle_t s)
{
	Stack_t *ps = s;
	BaseType_t res;

	if (ps == NULL)
		return -1;

	if (ps->top == NULL)
		res = 1;
	else
		res = 0;

	return res;
}

BaseType_t StackIsFull(StackHandle_t s)
{
	Stack_t *ps = s;
	BaseType_t res;

	if (ps == NULL)
		return -1;

	if (ps->top == ps->tail)
		res = 1;
	else
		res = 0;

	return res;
}

/* API�� �յ� */
