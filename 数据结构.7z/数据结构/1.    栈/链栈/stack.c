#include "stack.h"
#include <stdlib.h>  //����C���malloc��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *stack_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ���Ҫ >= UBaseType_t

	return p;
}

static void stack_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void stack_memcpy(unsigned char *d, unsigned char *s, UBaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

/* ��̬�� �յ� */



/* API�� ���*/

StackHandle_t StackCreate(UBaseType_t nodeSize, UBaseType_t length)
{
	Stack_t *ps;

	if (nodeSize == 0 || length == 0)
		return NULL;

	ps = (Stack_t *)stack_malloc(sizeof(Stack_t));

	if (ps != NULL)
	{
		ps->top = NULL;
		ps->nodeSize = nodeSize;
		ps->length = length;
		ps->messages = 0;
	}

	return ps;
}

void StackDelete(StackHandle_t s)
{
	Stack_t *ps = s;
	StackNode_t *pNode, *pNextNode;

	if (ps == NULL)
		return;

	pNode = ps->top;
	while (pNode != NULL)
	{
		pNextNode = pNode->next;
		stack_free((void *)pNode);
		pNode = pNextNode;
	}

	stack_free((void *)ps);
}

BaseType_t StackPush(StackHandle_t s, void *p)
{
	Stack_t *ps = s;
	StackNode_t *pn;
	BaseType_t res;

	if (ps->messages >= ps->length)
	{
		res = 0;
	}
	else
	{
		pn = (StackNode_t *)stack_malloc(sizeof(StackNode_t) + ps->nodeSize);
		if (pn != NULL)
		{
			stack_memcpy((unsigned char *)pn + sizeof(StackNode_t), (unsigned char *)p, ps->nodeSize);
			pn->next = ps->top;
			ps->top = pn;
			ps->messages++;
			res = 1;
		}
		else
			res = 0;
	}

	return res;
}

BaseType_t StackPop(StackHandle_t s, void *p)
{
	Stack_t *ps = s;
	StackNode_t *pn;
	BaseType_t res;

	if (ps->messages == 0)
	{
		res = 0;
	}
	else
	{
		pn = ps->top;
		stack_memcpy((unsigned char *)p, (unsigned char *)pn+sizeof(StackNode_t), ps->nodeSize);
		ps->top = pn->next;
		ps->messages--;
		stack_free((void *)pn);

		res = 1;
	}
	
	return res;
}

BaseType_t StackGetTop(StackHandle_t s, void *p)
{
	Stack_t *ps = s;
	StackNode_t *pn;
	BaseType_t res;

	if (ps->messages == 0)
	{
		res = 0;
	}
	else
	{
		pn = ps->top;
		stack_memcpy((unsigned char *)p, (unsigned char *)pn + sizeof(StackNode_t), ps->nodeSize);

		res = 1;
	}

	return res;
}

BaseType_t StackIsEmpty(StackHandle_t s)
{
	Stack_t *ps = s;
	BaseType_t res;

	if (ps == NULL)
		return -1;

	if (ps->messages == 0)
		res = 1;
	else
		res = 0;

	return res;
}

BaseType_t StackIsFull(StackHandle_t s)
{
	Stack_t *ps = s;
	BaseType_t res;

	if (ps == NULL)
		return -1;

	if (ps->messages == ps->length)
		res = 1;
	else
		res = 0;

	return res;
}

/* API�� �յ� */
