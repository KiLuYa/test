#include "bstree.h"
#include <stdlib.h>  //����mallco��free����


#ifndef NULL
#define NULL 0
#endif


/* �ӿ��� ��� */

static void *bstree_malloc(UBaseType_t size)
{
	void *p = malloc(size);  //malloc �Ĳ������ͱ��� >= UBaseType_t

	return p;
}

static void bstree_free(void *p)
{
	free(p);
}

/* �ӿ��� �յ� */



/* ��̬�� ��� */

static void bstree_memcpy(unsigned char *d, unsigned char *s, UBaseType_t size)
{
	while (size--)
		*d++ = *s++;
}

static BaseType_t bstree_memcmp(unsigned char *a1, unsigned char *a2, UBaseType_t size)
{
	int ret = 0;

	while (size--)
	{
		if (*a1 == *a2)
		{
			a1++;
			a2++;
			continue;
		}
		if (*a1 > *a2)
		{
			ret = 1;
			break;
		}
		else
		{
			ret = -1;
			break;
		}
	}
	return ret;
}


/* by post order traversal */
static void deleteBSTree(BSTreeNode_t *pn)
{
	if (pn != NULL)
	{
		deleteBSTree(pn->left);
		deleteBSTree(pn->right);
		bstree_free(pn);
	}
}

static BaseType_t insertBSTree(BSTreeNode_t **ppn, void *data, BSTreeNodeCompareFunc_t compareFunc, UBaseType_t size)
{
	BSTreeNode_t *pn;
	BaseType_t ret;

	if (*ppn == NULL)
	{
		pn = (BSTreeNode_t *)malloc((UBaseType_t)sizeof(BSTreeNode_t)+size);
		if (pn != NULL)
		{
			bstree_memcpy((unsigned char *)pn + sizeof(BSTreeNode_t), data, size);
			pn->left = NULL;
			pn->right = NULL;
			*ppn = pn;
			ret = 1;
		}
		else
			ret = 0;
	}
	else
	{
		if (compareFunc((void *)((unsigned char *)(*ppn) + sizeof(BSTreeNode_t)), data) > 0)
			ret = insertBSTree(&((*ppn)->left), data, compareFunc, size);
		else
			ret = insertBSTree(&((*ppn)->right), data, compareFunc, size);
	}

	return ret;
}

static void *searchBSTree(BSTreeNode_t *pn, void *data, BSTreeNodeCompareFunc_t compareFunc)
{
	void *node_arg;
	BaseType_t res;
	void *ret;
	
	if (pn != NULL)
	{
		node_arg = (unsigned char *)pn + sizeof(BSTreeNode_t);
		res = compareFunc(node_arg, data);
		if (res == 0)
			ret = node_arg;
		else if (res > 0)
			ret = searchBSTree(pn->left, data, compareFunc);
		else
			ret = searchBSTree(pn->right, data, compareFunc);
	}
	else
		ret = NULL;

	return ret;
}

/* by pre order traversal */
static BSTreeNode_t *copyBitree(BSTreeNode_t *pn, UBaseType_t size, BaseType_t *err)
{
	BSTreeNode_t *pn1 = NULL;

	if (*err == 0)
	{
		if (pn != NULL)
		{
			pn1 = bstree_malloc((UBaseType_t)sizeof(BSTreeNode_t) + size);
			if (pn1 != NULL)
			{
				pn1->left = NULL;
				pn1->right = NULL;
				bstree_memcpy((unsigned char*)pn1 + sizeof(BSTreeNode_t), (unsigned char *)pn + sizeof(BSTreeNode_t), size);
				pn1->left = copyBitree(pn->left, size, err);
				pn1->right = copyBitree(pn->right, size, err);
			}
			else
				*err = 1;
		}
		else
			pn1 = NULL;
	}

	return pn1;
}

static void inOrder(BSTreeNode_t *pn, void *arg, BSTreeNodeVisitFunc_t visit)
{
	if (pn != NULL)
	{
		inOrder(pn->left, arg, visit);
		visit((void *)((unsigned char*)pn + sizeof(BSTreeNode_t)), arg);
		inOrder(pn->right, arg, visit);
	}
}

static void reInOrder(BSTreeNode_t *pn, void *arg, BSTreeNodeVisitFunc_t visit)
{
	if (pn != NULL)
	{
		reInOrder(pn->right, arg, visit);
		visit((void *)((unsigned char*)pn + sizeof(BSTreeNode_t)), arg);
		reInOrder(pn->left, arg, visit);
	}
}

/* by post order traversal */
static UBaseType_t cntBitreeHeight(BSTreeNode_t *pn)
{
	UBaseType_t hl, hr, hig;

	if (pn != NULL)
	{
		hl = cntBitreeHeight(pn->left);
		hr = cntBitreeHeight(pn->right);
		hig = hl > hr ? hl : hr;
		hig = hig + 1;
	}
	else
		hig = 0;

	return hig;
}

/* by inverse-inorder traversal */
static void printBitree_0(BSTreeNode_t *pn, UBaseType_t spaces)
{
	UBaseType_t i;

	if (pn != NULL)
	{
		printBitree_0(pn->right, spaces + 1);
		for (i = 0; i < spaces; i++)
			printf(" ");
		printf("%d\n", *(int *)((char *)pn + sizeof(BSTreeNode_t)));
		printBitree_0(pn->left, spaces + 1);
	}
}

static void printBitree_1(BSTreeNode_t *pn, UBaseType_t spaces)
{

}

/* ��̬�� �յ� */



/* API�� ��� */

BSTreeHandle_t BSTreeCreate(UBaseType_t nodeSize, UBaseType_t nodesNumLimit, BSTreeNodeCompareFunc_t compareFunc, BSTreeNodeVisitFunc_t visitFunc)
{
	BSTree_t *pt;

	if (nodeSize == 0)
		return NULL;

	pt = (BSTree_t *)bstree_malloc(sizeof(BSTree_t));

	if (pt != NULL)
	{
		pt->root = NULL;
		pt->nodeSize = nodeSize;
		pt->nodesNum = 0;
		pt->nodesNumLimit = nodesNumLimit;
		pt->compareFunc = compareFunc;
		pt->visitFunc = visitFunc;
	}

	return pt;
}

void BSTreeDelete(BSTreeHandle_t bst)
{
	BSTree_t *pt = bst;

	if (pt != NULL)
	{
		deleteBSTree(pt->root);
		bstree_free(pt);
	}
}

BaseType_t BSTreeInsert(BSTreeHandle_t bst, void *data)
{
	BSTree_t *pt = bst;
	BaseType_t ret = 0;

	if (pt != NULL)
		ret = insertBSTree(&(pt->root), data, pt->compareFunc, pt->nodeSize);
	if (ret != 0)
		pt->nodesNum++;
	
	return ret;
}

BaseType_t BSTreeRemove(BSTreeHandle_t bst, void *data)
{
	return 0;
}

void *BSTreeSearch(BSTreeHandle_t bst, void *data)
{
	BSTree_t *pt = bst;
	void *ret;

	if (pt != NULL)
		ret = searchBSTree(pt->root, data, pt->compareFunc);
	else
		ret = NULL;

	return ret;
}

BSTreeHandle_t BSTreeCopy(BSTreeHandle_t bst)
{
	BSTree_t *pst = bst;
	BSTree_t *pdt;
	BaseType_t err;

	if (pst == NULL)
		return NULL;

	pdt = (BSTree_t *)bstree_malloc(sizeof(BSTree_t));

	if (pdt != NULL)
	{
		pdt->root = NULL;
		pdt->nodeSize = pst->nodeSize;
		pdt->nodesNum = pst->nodesNum;
		pdt->nodesNumLimit = pst->nodesNumLimit;
		pdt->compareFunc = pst->compareFunc;
		pdt->visitFunc = pst->visitFunc;

		err = 0;
		pdt->root = copyBitree(pst->root, pst->nodeSize, &err);
		if (err == 1)
		{
			BSTreeDelete(pdt);
			pdt = NULL;
		}
	}

	return pdt;
}

void BSTreeInOrder(BSTreeHandle_t bst, void *arg)
{
	BSTree_t *pt = bst;

	if (pt != NULL)
		inOrder(pt->root, arg, pt->visitFunc);
}

void BSTreeReInOrder(BSTreeHandle_t bst, void *arg)
{
	BSTree_t *pt = bst;

	if (pt != NULL)
		reInOrder(pt->root, arg, pt->visitFunc);
}

UBaseType_t BSTreeGetNodesNum(BSTreeHandle_t bst)
{
	BSTree_t *pt = bst;
	UBaseType_t ret = 0;

	if (pt != NULL)
		ret = pt->nodesNum;

	return ret;
}

UBaseType_t BSTreeGetHeight(BSTreeHandle_t bst)
{
	BSTree_t *pt = bst;
	UBaseType_t hig = 0;

	if (pt != NULL)
		hig = cntBitreeHeight(pt->root);

	return hig;
}

UBaseType_t BSTreeGetWidth(BSTreeHandle_t bst)
{
	return 0;
}

void BSTreeSetNodeCompareFunc(BSTreeHandle_t bst, BSTreeNodeCompareFunc_t compareFunc)
{
	BSTree_t *pt = bst;

	if (pt != NULL)
		pt->compareFunc = compareFunc;
}

void BSTreeSetNodeVisitFunc(BSTreeHandle_t bst, BSTreeNodeVisitFunc_t visitFunc)
{
	BSTree_t *pt = bst;

	if (pt != NULL)
		pt->visitFunc = visitFunc;
}

void BSTreePrint(BSTreeHandle_t bst, UBaseType_t dir)
{
	BSTree_t *pt = bst;

	if (pt == NULL)
		return;

	if (dir == 0)
		printBitree_0(pt->root, 0);
	else
		printBitree_1(pt->root, 0);
}

/* API�� �յ� */
